var owaurl;
var owaaccount;
var officeFile = new Array();
function fileviewUrl(filename, filetype, fileoldname, rootpath) {
    if (owaurl == null || owaurl == undefined) {
        initowa(rootpath);
    }
    if (filetype.indexOf('.') > -1) {
        filetype = filetype.split('.')[filetype.split('.').length - 1];
    }
    if ($.inArray(filetype.toLowerCase(), officeFile) >= 0) {
        var secret = "";

        return owaurl + '?account=' + owaaccount + '&src=' + filename + '&type=' + filetype + '&secret=' + secret;
    }
    return "";
}
function ChangeDateFormat(cellval) {
    var date = new Date(parseInt(cellval.replace("/Date(", "").replace(")/", ""), 10));
    var month = date.getMonth() + 1 < 10 ? "0" + (date.getMonth() + 1) : date.getMonth() + 1;
    var currentDate = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
    return date.getFullYear() + "-" + month + "-" + currentDate;
}

$.htmlEncode = function (str) {
    var div = document.createElement("div");
    var text = document.createTextNode(str);
    div.appendChild(text);
    return div.innerHTML;
}
$.htmlDecode = function (str) {
    var div = document.createElement("div");
    div.innerHTML = str;
    return div.innerHTML;
}

$.editimg = function (html, rootpath) {
    var pathlist = new Array();
    pathlist.push("/cms");
    pathlist.push("/manage");
    pathlist.push("http://oa.corpautohome.com/eip/");
    pathlist.push("http://oa.corpautohome.com/cms/");
    pathlist.push("http://oa.corpautohome.com");
    if (html != null && html != undefined && html != "") {
        if (rootpath != null && rootpath != undefined && rootpath != "") {
            var obj = $("<div></div>");
            obj.append(html);
            obj.find("img").each(function (index, item) {
                if ($(item).attr("src") != null && $(item).attr("src") != undefined && $(item).attr("src") != "") {
                    if (pathlist != null && pathlist != undefined && pathlist.length > 0) {
                        for (var i = 0; i < pathlist.length; i++) {
                            if ($(item).attr("src").toLocaleLowerCase().indexOf(pathlist[i].toLocaleLowerCase()) == 0) {
                                var srcstring = $(item).attr("src");
                                srcstring = srcstring.substring(pathlist[i].length + 1, srcstring.length);
                                if (srcstring.indexOf("/") != 0) {
                                    $(item).attr("src", rootpath + "/" + srcstring);
                                }
                                else {
                                    $(item).attr("src", rootpath + srcstring);
                                }
                            }
                        }
                    }
                    if ($(item).attr("src").toLocaleLowerCase().indexOf(rootpath.toLocaleLowerCase()) == -1) {
                        if ($(item).attr("src").indexOf("/") == -1) {
                            $(item).attr("src", rootpath + "/" + $(item).attr("src"));
                        } else {
                            $(item).attr("src", rootpath + $(item).attr("src"));
                        }
                    }
                }
            });
            return obj.html();
        }
        return html;
    }
    return "";
}
var indexA;
/*
 *展示详细内容
 */
function showMessageTips(message, obj) {
    indexA = layer.tips($.htmlEncode(message), obj, {
        style: ['background-color:#E227C7; color:#fff', '#E227C7'],
        maxWidth: 285,
        time: 999999
    });
    $(".layui-layer-close").css("right", "-12px").css("top", "-8px");
    $(".layui-layer-content").css("word-wrap", "break-word").css("word-break", "break-all").css("width", "291px").css('padding-right', '5px');
}
function CloseTips() {
    layer.close(indexA);
}
;(function ($) {
    if ($ != null && $ != undefined) {
        //备份jquery的ajax方法
        var _ajax = $.ajax;
        //重写jquery的ajax方法
        $.ajax = function (opt) {
            var data = {
                rand: Math.random()
            };
            var fn = {
                complete: function (event, xhr, options) {
                }
            }
            if (opt.complete) {
                fn.complete = opt.complete;
            }
            var newdata = $.extend(data, opt.data);
            opt.data = newdata;
            opt.complete = function (event, xhr, options) {
                fn.complete();
                updatelink();
            }
            _ajax(opt);
        };
    }
})(jQuery);


function alertt(mess, callback) {
    layer.alert(mess, function (index) {
        if (callback) {
            callback();
        }
        layer.close(index);
    });
}

function confirmm(mess, callback) {
    layer.confirm(mess, {
        btn: ['确定', '取消'] //按钮
    }, function (index) {
        if (callback) {
            callback();
        }
        layer.close(index);
    });
}

function msgg(mess, callback) {
    layer.msg(mess, {
        time: 1500 //2秒关闭（如果不配置，默认是3秒）
    }, function () {
        if (callback) {
            callback();
        }
    });
}

function startloading() {
    try {
        layer.load();
    }
    catch (e) {
    }
}

function closeloading() {
    try {
        layer.closeAll('loading');
    }
    catch (e) {
    }
}

function initowa(rootpath) {
    $.ajax({
        url: rootpath + "/home/GetConfig",
        type: 'GET',
        async: false,
        data: {
            key: "OWAURL"
        },
        success: function (data) {
            owaurl = data;
        },
        dataType: "text"
    });
    $.ajax({
        url: rootpath + "/home/GetConfig",
        type: 'GET',
        async: false,
        data: {
            key: "OWAAccount"
        },
        success: function (data) {
            owaaccount = data;
        },
        dataType: "text"
    });

    $.ajax({
        url: rootpath + "/home/GetConfig",
        type: 'GET',
        async: false,
        data: {
            key: "ViewFileType"
        },
        success: function (data) {
            if (data != null && data != undefined && data != "" && data.length > 0) {
                officeFile = data.split(",");
            }
        },
        dataType: "text"
    });
}


function mysubstr(value, n) {
    if (value != null && $.trim(value).length > 0) {
        var r = /[^\x00-\xff]/g;
        if (value.replace(r, "mm").length <= n) {
            return value;
        }
        var m = Math.floor(n / 2);
        for (var i = m; i < value.length; i++) {
            if (value.substr(0, i).replace(r, "mm").length >= n) {
                return value.substr(0, i) + "...";
            }
        }
    }
    return "";
}

// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}
function updatelink() {
    //javascript:void(0)
    $("a").each(function (index, item) {
        if ($(item).attr("href") == "#") {
            $(item).attr("href", "javascript:void(0)");
        }
    });

}
$(document).ready(function () {
    updatelink();
});