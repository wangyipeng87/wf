﻿(function ($) {

    $.fn.FTPUploadify = function (options) {
        // 这里提供默认参数
        var defaults = {
            buttonClass:'',
            auto: true,
            multi: true,
            width: '60',
            height: '20',
            fileSizeLimit:"20MB",
            queueID: 'queue',
            uploader:'/uploadfile/ftp/',
            buttonText: '选择文件',
            fileType:false,
            fileTypeExts:'*.*',
            onUploadSuccess: function (file, data) {
                $("#queue").html("");
                jsonData = eval('(' + data + ')');
                if (jsonData.IsSuccess) {
                    UploadPostBack(jsonData.Data);
                }
                else {
                    alert(jsonData.Message);
                }
            }
        };

        var settings = $.extend({}, defaults, options);

        this.each(function () {
            var elem = $(this);
            //判断浏览器是否支持html5
            if (window.applicationCache) {
                elem.uploadifive({
                    'buttonClass':settings.buttonClass,
                    'formData': settings.formData,
                    'auto': settings.auto,
                    'checkScript': '',
                    'buttonText': settings.buttonText,
                    'queueID': settings.queueID,
                    'height': settings.height,
                    'width': settings.width,
                    'fileSizeLimit':settings.fileSizeLimit,
                    'uploadScript': settings.uploader,
                    'multi': settings.multi,
                    'fileType': settings.fileType,
                    'onUploadComplete': settings.onUploadSuccess
                });
            }
            else
            {
                elem.uploadify({
                    'buttonClass':settings.buttonClass,
                    'formData': settings.formData,
                    'swf': '/Static/CMS/Plugin/uploadify/uploadify.swf',
                    'uploader': settings.uploader,
                    'cancelImg': '/Static/CMS/Plugin/uploadify/cancel.png',
                    'queueID': settings.queueID,
                    'buttonText': settings.buttonText,
                    'auto': settings.auto,
                    'multi': settings.multi,
                    'height': settings.height,
                    'fileSizeLimit':settings.fileSizeLimit,
                    'width': settings.width,
                    'fileTypeExts': settings.fileTypeExts,
                    'onUploadSuccess': settings.onUploadSuccess
                });
            }
        });
        return this;
    };

}(jQuery));


//上传附件的回调函数
function UploadPostBack(res)
{
    var html = "<tr id=\"" + res.ID + "\">";
    html += "<td>";
    html += "<input type=\"hidden\" class=\"id\" value=\"" + res.ID + "\" />";
    html += "<input type=\"hidden\" class=\"size\" value=\"" + res.FileSize + "\" />";
    html += "<input type=\"hidden\" class=\"path\" value=\"" + res.FilePath + "\" />";
    html += "<input type=\"hidden\" class=\"name\" value=\"" + res.FileName + "\" />";
    html += "<input type=\"hidden\" class=\"suffix\" value=\"" + res.FileSuffix + "\" />";
    html += "<a href=\"/uploadfile/ftpDownload?filepath=" + res.ID + res.FileSuffix + "&filename=" + res.FileName + "\" class=\"marginright20\" target=\"_blank\">" + res.FileName + "</a>";
    html += "<a href=\"javascript:void(0)\" class=\"red\" onclick=\"removefile('" + res.ID + "')\">删除</a>";
    html += "</td>";
    html += "</tr>";
    $("#tbFiles").append(html);
}

//删除附件
function removefile(id)
{
    if (confirm("确定要删除该文件？"))
    {
        $("#" + id).remove();
    }
}