package com.autohome.cms.controller;

import com.autohome.cms.Entity.T_cms_tmp;
import com.autohome.cms.Entity.T_employee;
import com.autohome.cms.Entity.tmpfile;
import com.autohome.cms.service.TmpService;
import com.autohome.common.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.activation.MimetypesFileTypeMap;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.*;

/**
 * Created by Administrator on 2017/5/16.
 */
@Controller
public class tmpControler extends baseController {

    @Resource
    TmpService _tmpService;

    @Value("#{configProperties['UpTmpPath']}")
    private String UpTmpPath;

    @Value("#{configProperties['AccessTmpUrl']}")
    private String AccessTmpUrl;

    @RequestMapping("/tmp/list")
    public ModelAndView listPage(){
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/TmpManage/TmpList");
        mod.addObject("username",emp.getUsername());
        return mod;
    }

    @RequestMapping("/tmp/add")
    public ModelAndView add(){
        String fromname="编辑";
        String id=helper.getParameter("id");
        if(id==null||id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
            fromname="添加";
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/TmpManage/AddTmp");
        mod.addObject("username",emp.getUsername());
        mod.addObject("id",id);
        mod.addObject("fromname", fromname);
        return mod;
    }


    @RequestMapping("/tmp/filelist")
    public ModelAndView filelistPage()
    {
        String id=helper.getParameter("id");
        if(id==null||id.equals(""))
        {
            id = java.util.UUID.randomUUID().toString();
        }
        String folder="";
        T_cms_tmp entity =_tmpService.findTmpbyID(id);
        if(entity!=null) {
            folder=entity.getFoldername();
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/TmpManage/TmpFileList");
        mod.addObject("username",emp.getUsername());
        mod.addObject("id",id);
        mod.addObject("folder",folder);
        mod.addObject("AccessTmpUrl",AccessTmpUrl.trim());
        return mod;
    }

    @RequestMapping("/tmp/addfile")
    public ModelAndView addfile(HttpServletRequest request, HttpServletResponse response, HttpSession session){
        String id=helper.getParameter("id");
        if(id==null||id.equals(""))
        {
            id = java.util.UUID.randomUUID().toString();
        }
        String strfile=helper.getParameter("file");
        String strfilecontent="";
        String strcodemirrormode="htmlmixed";
        String strPath=session.getServletContext().getRealPath(UpTmpPath.trim()+strfile);
        File f = new File(strPath);
        if(f.exists())
        {
            strfilecontent=getFileString(f);
            if(f.getName().toLowerCase().endsWith(".css")) {
                strcodemirrormode="css";
            }
            else if(f.getName().toLowerCase().endsWith(".js")) {
                strcodemirrormode="javascript";
            }
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/TmpManage/AddTmpFile");
        mod.addObject("username",emp.getUsername());
        mod.addObject("id",id);
        mod.addObject("file",strfile);
        mod.addObject("path",strPath);
        mod.addObject("content",org.apache.commons.lang3.StringEscapeUtils.escapeHtml4(strfilecontent));
        mod.addObject("codemirrormode",strcodemirrormode);
        return mod;
    }


    @RequestMapping("/tmp/GetAllList")
    @ResponseBody
    public Result GetList(String name, String code, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start==0?start:start+1;
        int end=start==0?start+length:start+length;
        Result res=new Result();
        name= helper.unescape(name);
        code=helper.unescape(code);
        ArrayList<T_cms_tmp> list = new ArrayList<T_cms_tmp>();
        try {
            list=_tmpService.findAllTmpPager(name,code,orderdata,orderdir,begin,end);
            if(list==null)
            {
                list = new ArrayList<T_cms_tmp>();
            }
            int tot=_tmpService.findAllTmpCount(name,code);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/tmp/updatestate")
    @ResponseBody
    public ResultMsg updatestate(String id, int state) {
        ResultMsg ret=new ResultMsg();
        try {
            T_cms_tmp entity =new T_cms_tmp();
            entity.setId(id);
            entity.setState(new Long(state));
            entity.setUpdateusercode(getCurrentUser().getUsercode());
            int result=_tmpService.updateState(entity);
            if(result>0) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/tmp/getbyid")
    @ResponseBody
    public T_cms_tmp getbyid(@RequestParam(value = "id") String id){
        T_cms_tmp entity= _tmpService.findTmpbyID(id);
        if(entity==null) {
            entity=new T_cms_tmp();
            entity.setId(java.util.UUID.randomUUID().toString());
            entity.setState(new Long(1));
        }
        return entity;
    }

    @RequestMapping("/tmp/savetmp")
    @ResponseBody
    public ResultMsg savetmp(String id, String tmpname, String tmpcode, String foldername,int state,String sampleurl,String remark) {
        ResultMsg ret=new ResultMsg();
        try {
            T_cms_tmp entity =_tmpService.findTmpbyID(id);
            if(entity==null)
            {
                T_cms_tmp selective=new T_cms_tmp();
                selective.setTmpcode(helper.unescape(tmpcode));
                ArrayList<T_cms_tmp> chklist=_tmpService.findTmpBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    ret.setState(0);
                    ret.setMsg("模板编号已存在");
                    return ret;
                }
                selective=new T_cms_tmp();
                selective.setFoldername(helper.unescape(foldername));
                chklist=_tmpService.findTmpBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    ret.setState(0);
                    ret.setMsg("模板目录已存在");
                    return ret;
                }
                entity=new T_cms_tmp();
                entity.setId(java.util.UUID.randomUUID().toString());
                entity.setState(new Long(state));
                entity.setCreateusercode(getCurrentUser().getUsercode());
                entity.setSampleurl(helper.unescape(sampleurl));
                entity.setTmpname(helper.unescape(tmpname));
                entity.setTmpcode(helper.unescape(tmpcode));
                entity.setFoldername(helper.unescape(foldername));
                entity.setRemark(helper.unescape(remark));
                entity.setUpdateusercode(getCurrentUser().getUsercode());
                int result=_tmpService.insert(entity);
                if(result>0) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
            else
            {
                T_cms_tmp selective=new T_cms_tmp();
                selective.setTmpcode(helper.unescape(tmpcode));
                List<T_cms_tmp> chklist=_tmpService.findTmpBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    long chkcount=chklist.stream().filter(chk -> !chk.getId().equals(id)).count();
                    if(chkcount>0) {
                        ret.setState(0);
                        ret.setMsg("模板编号已存在");
                        return ret;
                    }
                }
                selective=new T_cms_tmp();
                selective.setFoldername(helper.unescape(foldername));
                chklist=_tmpService.findTmpBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    long chkcount=chklist.stream().filter(chk -> !chk.getId().equals(id)).count();
                    if(chkcount>0) {
                        ret.setState(0);
                        ret.setMsg("模板目录已存在");
                        return ret;
                    }
                }
                entity.setState(new Long(state));
                entity.setSampleurl(helper.unescape(sampleurl));
                entity.setTmpname(helper.unescape(tmpname));
                entity.setTmpcode(helper.unescape(tmpcode));
                entity.setFoldername(helper.unescape(foldername));
                entity.setRemark(helper.unescape(remark));
                entity.setUpdateusercode(getCurrentUser().getUsercode());
                int result=_tmpService.update(entity);
                if(result>0) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存模板异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }


    @RequestMapping("/tmp/GetAllFileList")
    @ResponseBody
    public Result GetFileList(String id, String name, int draw, int start, int length, HttpServletRequest request, HttpServletResponse response, HttpSession session)
    {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start;
        int end=start+length;
        Result res=new Result();
        id= helper.unescape(id);
        name=helper.unescape(name);
        ArrayList<tmpfile> list = new ArrayList<tmpfile>();
        try {
            T_cms_tmp entity =_tmpService.findTmpbyID(id);
            if(entity!=null)
            {
                String tmpAbsolutePath=session.getServletContext().getRealPath(UpTmpPath.trim() + (UpTmpPath.trim().endsWith("/") ? "" : "/") + entity.getFoldername() + "/");
                list=getTmpFileList(tmpAbsolutePath,tmpAbsolutePath,name);
                if (list!=null && list.size()>0)
                {
                    ListSortUtil<tmpfile> sortList = new ListSortUtil<tmpfile>();
                    sortList.sort(list,orderdata,orderdir);
                    int num=1;
                    for (tmpfile tf : list)
                    {
                        tf.setIndex(num++);
                    }
                }
            }
            int tot=list.size();
            if(tot<end)
            {
                end = tot;
            }
            res.setdata(list.subList(begin,end));
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/tmp/savetmpfile")
    @ResponseBody
    public ResultMsg savetmpfile(String id, String path, String file, String remark) {
        ResultMsg ret=new ResultMsg();
        try {
            File f = new File(helper.unescape(path));
            if (f.exists()) {
                OutputStreamWriter write = new OutputStreamWriter(new FileOutputStream(f),"UTF-8");
                BufferedWriter output = new BufferedWriter(write);
                output.write(helper.unescape(remark));
                output.flush();
                write.close();
                output.close();
                ret.setState(1);
                ret.setMsg("保存成功");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存模板文件异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }







    public ArrayList<tmpfile> getTmpFileList(String strRootPath,String strPath,String strName) {
        ArrayList<tmpfile> tmpfilelist=new ArrayList<tmpfile>();
        File dir = new File(strPath);
        if (dir.exists())
        {
            File[] files = dir.listFiles(); // 该文件目录下文件全部放入数组
            if (files != null) {
                for (File f : files) {
                    if (!f.isDirectory())
                    {
                        if (strName.isEmpty() || f.getName().indexOf(strName) != -1)
                        {
                            tmpfile tf = new tmpfile();
                            tf.setFilename(f.getName());
                            tf.setFilepath(f.getPath());
                            tf.setParentpath(f.getParent());
                            tf.setIsdir(f.isDirectory() ? 1 : 0);
                            tf.setFilesize(f.length());
                            Calendar cal = Calendar.getInstance();
                            cal.setTimeInMillis(f.lastModified());
                            tf.setCreatetime(new java.sql.Timestamp(cal.getTimeInMillis()));
                            tf.setUpdatetime(new java.sql.Timestamp(cal.getTimeInMillis()));
                            tf.setTmpurl(tf.getFilepath().replace(new File(strRootPath).getParent(),"").replace(File.separator,"/"));
                            if(f.getName().toLowerCase().endsWith(".jsp"))
                            {
                                tf.setContenttype("text/html");
                            }
                            else
                            {
                                try {
                                    tf.setContenttype(Files.probeContentType(f.toPath()));
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                if (tf.getContenttype() == null || tf.getContenttype().isEmpty()) {
                                    tf.setContenttype(new MimetypesFileTypeMap().getContentType(f));
                                }
                            }
                            tmpfilelist.add(tf);
                        }
                    }
                    else
                    {
                        tmpfilelist.addAll(getTmpFileList(strRootPath,f.getAbsolutePath(),strName)); // 获取文件绝对路径
                    }
                }
            }
        }
        return tmpfilelist;
    }

    public String getFileString(File file){
        StringBuilder result = new StringBuilder();
        try{
            InputStreamReader isr = new InputStreamReader(new FileInputStream(file),"UTF-8");
            BufferedReader br = new BufferedReader(isr);//构造一个BufferedReader类来读取文件
            String s = null;
            while((s = br.readLine())!=null){//使用readLine方法，一次读一行
                result.append(System.lineSeparator()+s);
            }
            br.close();
        }catch(Exception e){
            result.append(e.toString());
        }
        return result.toString();
    }




    @RequestMapping("/tmp/ftp")
    public ModelAndView ftptest(){
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/TmpManage/ftptest");
        mod.addObject("username",emp.getUsername());
        return mod;
    }

}
