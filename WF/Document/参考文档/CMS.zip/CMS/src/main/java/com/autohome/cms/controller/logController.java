package com.autohome.cms.controller;

import com.autohome.cms.Entity.*;
import com.autohome.cms.service.ErrorLogService;
import com.autohome.cms.service.LoginLogService;
import com.autohome.cms.service.OperationLogService;
import com.autohome.cms.service.VisitLogService;
import com.autohome.common.LoggerHelper;
import com.autohome.common.Result;
import com.autohome.common.helper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.ArrayList;

/**
 * Created by Administrator on 2017/6/13.
 */
@Controller
public class logController extends baseController {

    @Resource
    ErrorLogService _errorLogService;

    @Resource
    LoginLogService _loginLogService;

    @Resource
    VisitLogService _visitLogService;

    @Resource
    OperationLogService _operationLogService;

    @RequestMapping("/log/loginlist")
    public ModelAndView LoginList() {
        ModelAndView mod = new ModelAndView("jsps/CMS/LogManage/LoginList");
        mod.addObject("name", "登录日志");
        return mod;
    }

    @RequestMapping("/log/GetLoginListByPage")
    @ResponseBody
    public Result GetLoginListByPage(String keyword, String ip, String begindate, String enddate, int start, int length) {
        T_employee currentUser = this.getCurrentUser();
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        keyword = helper.unescape(keyword);
        if (begindate.length() > 0) {
            begindate = helper.unescape(begindate + " 00:00:00");
        }
        if (enddate.length() > 0) {
            enddate = helper.unescape(enddate + " 23:59:59");
        }
        ip = helper.unescape(ip);
        ArrayList<T_cms_loginlog> list = new ArrayList<T_cms_loginlog>();
        try {
            list = _loginLogService.findListByPage(keyword, begindate, enddate, ip, orderdata, orderdir, begin, end);
            int tot = _loginLogService.findListByPageCount(keyword, begindate, enddate, ip);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_cms_loginlog>();
            }
            res.setdata(list);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询登录日志列表获取数据异常，操作人:" + currentUser.getUsername() + "(" + currentUser.getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/log/errorlist")
    public ModelAndView ErrorList() {
        ModelAndView mod = new ModelAndView("jsps/CMS/LogManage/ErrorList");
        mod.addObject("name", "错误日志");
        return mod;
    }

    @RequestMapping("/log/GetErrorListByPage")
    @ResponseBody
    public Result GetErrorListByPage(String name, int start, int length) {
        T_employee currentUser = this.getCurrentUser();
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        name = helper.unescape(name);
        ArrayList<T_errorlog> list = new ArrayList<T_errorlog>();
        try {
            list = _errorLogService.findListByPage(name, orderdata, orderdir, begin, end);
            int tot = _errorLogService.findListByPageCount(name);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_errorlog>();
            }
            res.setdata(list);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询错误日志列表获取数据异常，操作人:" + currentUser.getUsername() + "(" + currentUser.getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/log/operationlist")
    public ModelAndView OperationList() {
        ModelAndView mod = new ModelAndView("jsps/CMS/LogManage/OperationList");
        mod.addObject("name", "错误日志");
        return mod;
    }

    @RequestMapping("/log/GetOperationListByPage")
    @ResponseBody
    public Result GetOperationListByPage(String keyword, int start, int length) {
        T_employee currentUser = this.getCurrentUser();
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        keyword = helper.unescape(keyword);
        ArrayList<T_cms_operationlog> list = new ArrayList<T_cms_operationlog>();
        try {
            list = _operationLogService.findListByPage(keyword, orderdata, orderdir, begin, end);
            int tot = _operationLogService.findListByPageCount(keyword);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_cms_operationlog>();
            }
            res.setdata(list);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询操作日志列表获取数据异常，操作人:" + currentUser.getUsername() + "(" + currentUser.getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/log/visitlist")
    public ModelAndView VisitList() {
        ModelAndView mod = new ModelAndView("jsps/CMS/LogManage/VisitList");
        mod.addObject("name", "访问日志");
        return mod;
    }

    @RequestMapping("/log/GetVisitListByPage")
    @ResponseBody
    public Result GetVisitListByPage(String keyword, int start, int length) {
        T_employee currentUser = this.getCurrentUser();
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        keyword = helper.unescape(keyword);
        ArrayList<T_cms_visitlog> list = new ArrayList<T_cms_visitlog>();
        try {
            list = _visitLogService.findListByPage(keyword, orderdata, orderdir, begin, end);
            int tot = _visitLogService.findListByPageCount(keyword);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_cms_visitlog>();
            }
            res.setdata(list);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询访问日志列表获取数据异常，操作人:" + currentUser.getUsername() + "(" + currentUser.getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }
}
