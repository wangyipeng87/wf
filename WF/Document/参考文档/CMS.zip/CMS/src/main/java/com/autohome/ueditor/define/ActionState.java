package com.autohome.ueditor.define;

public enum ActionState {
	UNKNOW_ERROR
}
