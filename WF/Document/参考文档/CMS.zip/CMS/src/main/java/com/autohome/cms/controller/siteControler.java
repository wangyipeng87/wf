package com.autohome.cms.controller;

import com.autohome.cms.Entity.T_cms_site;
import com.autohome.cms.Entity.T_cms_tmp;
import com.autohome.cms.Entity.T_employee;
import com.autohome.cms.service.SiteService;
import com.autohome.cms.service.TmpService;
import com.autohome.common.LoggerHelper;
import com.autohome.common.Result;
import com.autohome.common.helper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.ArrayList;

/**
 * Created by Administrator on 2017/5/15.
 */
@Controller
public class siteControler extends baseController {

    @Resource
    SiteService _siteService;
    @Resource
    TmpService _tmpService;

    @RequestMapping("/site/list")
    public ModelAndView showHomePage(){
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/SiteManage/SiteList");
        mod.addObject("username",emp.getUsername());
        LoggerHelper.info("asdsa");
        return mod;
    }

    @RequestMapping("/site/GetAllList")
    @ResponseBody
    public Result GetList(String name, String code,int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start==0?start:start+1;
        int end=start==0?start+length:start+length;
        Result res=new Result();
        name=helper.unescape(name);
        code=helper.unescape(code);
        ArrayList<T_cms_site> list = new ArrayList<T_cms_site>();
        try {
            list=_siteService.findAllSite(name,code,orderdata,orderdir,begin,end);
            int tot=_siteService.findAllSiteCount(name,code);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }


    @RequestMapping("/site/add")
    public ModelAndView add(){
        String id=helper.getParameter("id");
        if(id==null||id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/SiteManage/AddSite");
        ArrayList<T_cms_tmp> list = new ArrayList<T_cms_tmp>();
        list=_tmpService.findAllTmp();
        mod.addObject("tmplist",list);
        mod.addObject("id",id);
        return mod;
    }

    @RequestMapping("/site/getbyid")
    @ResponseBody
    public T_cms_site getbyid(@RequestParam(value = "id") String id){
        T_cms_site site=     _siteService.findSitebyID(id);
        if(site==null) {
            site=new T_cms_site();
            site.setId(java.util.UUID.randomUUID().toString());
            site.setState(new Long(1));
        }
        return site;
    }
    @RequestMapping("/site/GetTmpList")
    @ResponseBody
    public ArrayList<T_cms_tmp> GetTmpList() {
        ArrayList<T_cms_tmp> list = new ArrayList<T_cms_tmp>();
        try {
            list=_tmpService.findAllTmp();
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }
    @RequestMapping("/site/savesite")
    @ResponseBody
    public int savesite(String id, String sitename, String sitecode, String prefix,String tmpcode,int state) {
        try {
            T_cms_site entity=new T_cms_site();
            entity =_siteService.findSitebyID(id);
            if(entity==null) {
                entity=new T_cms_site();
                entity.setId(java.util.UUID.randomUUID().toString());
            }
            entity.setState(new Long(state));
            entity.setCreateusercode(getCurrentUser().getUsercode());
            entity.setPrefix(helper.unescape(prefix));
            entity.setSitecode(helper.unescape(sitecode));
            entity.setSitename(helper.unescape(sitename));
            entity.setTmpCode(helper.unescape(tmpcode));
            entity.setUpdateusercode(getCurrentUser().getUsercode());
            _siteService.savesite(entity);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }
    @RequestMapping("/site/updatestate")
    @ResponseBody
    public int updatestate(String id, int state) {
        try {
            T_cms_site entity=new T_cms_site();
            entity =_siteService.findSitebyID(id);
            if(entity==null) {
                entity.setId(java.util.UUID.randomUUID().toString());
            }
            entity.setState(new Long(state));
            entity.setUpdateusercode(getCurrentUser().getUsercode());
            _siteService.savesite(entity);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }
}
