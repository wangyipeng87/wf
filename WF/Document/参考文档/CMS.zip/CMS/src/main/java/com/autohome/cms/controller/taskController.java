package com.autohome.cms.controller;

import com.autohome.common.HttpConnectUtil;
import com.autohome.common.MyTaskResult;
import com.autohome.common.TimestampTypeAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by gaonq on 2017/6/13.
 */
@Controller
public class taskController  extends baseController {
    @Value("#{configProperties['TaskAPIUrl']}")
    private String TaskAPIUrl;
    /*
    * 获取我的待办任务列表
     */
    @RequestMapping("/task/mytask")
    @ResponseBody
    public MyTaskResult getMyTaskList()
    {
        Map<String, String> msp = new HashMap<String, String>();
        msp.put("UserId",getCurrentUser().getUserid());
        msp.put("UserCode",getCurrentUser().getUsercode());
        msp.put("Source","");
        msp.put("FlowCode","");
        msp.put("AccountName",getCurrentUser().getAccountname());
        msp.put("CreateCode","");
        msp.put("ApplyBeginTime","");
        msp.put("ApplyEndTime","");
        msp.put("FormID","");
        msp.put("ProcessState","");
        msp.put("HandleBeginTime","");
        msp.put("HandleEndTime","");
        msp.put("Key","string");
        msp.put("Rows","4");
        msp.put("Page","1");
        msp.put("StartIndex","0");
        msp.put("EndIndex","0");

        String resJson = HttpConnectUtil.sendPost(TaskAPIUrl+"/api/ProcessTask/GetMyTaskList" , msp);
        Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        MyTaskResult entity = gson.fromJson(resJson, MyTaskResult.class);
        return entity;
    }
    /*
   * 获取我的已办任务列表
    */
    @RequestMapping("/task/myhandledtask")
    @ResponseBody
    public MyTaskResult getMyHandledTaskList()
    {
        Map<String, String> msp = new HashMap<String, String>();
        msp.put("UserId",getCurrentUser().getUserid());
        msp.put("UserCode",getCurrentUser().getUsercode());
        msp.put("Source","");
        msp.put("FlowCode","");
        msp.put("AccountName",getCurrentUser().getAccountname());
        msp.put("CreateCode","");
        msp.put("ApplyBeginTime","");
        msp.put("ApplyEndTime","");
        msp.put("FormID","");
        msp.put("ProcessState","");
        msp.put("HandleBeginTime","");
        msp.put("HandleEndTime","");
        msp.put("Key","string");
        msp.put("Rows","4");
        msp.put("Page","1");
        msp.put("StartIndex","0");
        msp.put("EndIndex","0");

        String resJson = HttpConnectUtil.sendPost(TaskAPIUrl+"/api/ProcessTask/GetHandledList" , msp);
        Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        MyTaskResult entity = gson.fromJson(resJson, MyTaskResult.class);
        return entity;
    }
    /*
  * 获取我的申请任务列表
   */
    @RequestMapping("/task/myapplytask")
    @ResponseBody
    public MyTaskResult getApplyListTaskList()
    {
        Map<String, String> msp = new HashMap<String, String>();
        msp.put("UserId",getCurrentUser().getUserid());
        msp.put("UserCode",getCurrentUser().getUsercode());
        msp.put("Source","");
        msp.put("FlowCode","");
        msp.put("AccountName",getCurrentUser().getAccountname());
        msp.put("CreateCode","");
        msp.put("ApplyBeginTime","");
        msp.put("ApplyEndTime","");
        msp.put("FormID","");
        msp.put("ProcessState","");
        msp.put("HandleBeginTime","");
        msp.put("HandleEndTime","");
        msp.put("Key","string");
        msp.put("Rows","4");
        msp.put("Page","1");
        msp.put("StartIndex","0");
        msp.put("EndIndex","0");

        String resJson = HttpConnectUtil.sendPost(TaskAPIUrl+"/api/ProcessTask/GetApplyList" , msp);
        Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        MyTaskResult entity = gson.fromJson(resJson, MyTaskResult.class);
        return entity;
    }
}
