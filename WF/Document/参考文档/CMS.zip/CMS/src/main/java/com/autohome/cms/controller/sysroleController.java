package com.autohome.cms.controller;

import com.autohome.cms.Entity.*;
import com.autohome.cms.service.*;
import com.autohome.common.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Administrator on 2017/6/3.
 */
@Controller
public class sysroleController extends baseController {


    @Resource
    SiteService _siteService;
    @Resource
    ModelService _modelService;
    @Resource
    SysRoleService _roleService;
    @Resource
    SysRoleUserService _roleUserService;
    @Resource
    SysRoleDeptService _roleDeptService;
    @Resource
    NavLinkRoleService _roleLinkService;

    @RequestMapping("/sysrole/list")
    public ModelAndView listPage(){
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/SysRoleManage/RoleList");
        mod.addObject("username",emp.getUsername());
        return mod;
    }

    @RequestMapping("/sysrole/add")
    public ModelAndView add(){
        String fromname="编辑";
        String id= helper.getParameter("id");
        if(id==null||id.equals(""))
        {
            id = java.util.UUID.randomUUID().toString();
            fromname="添加";
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/SysRoleManage/AddRole");
        mod.addObject("username",emp.getUsername());
        mod.addObject("id",id);
        mod.addObject("fromname", fromname);
        return mod;
    }


    @RequestMapping("/sysrole/GetAllList")
    @ResponseBody
    public Result GetList(String name, String code,String modelcode, String sitecode, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start==0?start:start+1;
        int end=start==0?start+length:start+length;
        Result res=new Result();
        name= helper.unescape(name);
        code= helper.unescape(code);
        modelcode= helper.unescape(modelcode);
        sitecode= helper.unescape(sitecode);
        ArrayList<T_cms_role> list = new ArrayList<T_cms_role>();
        try {
            list=_roleService.findAllPager(name,code,modelcode,sitecode,orderdata,orderdir,begin,end);
            if(list==null)
            {
                list = new ArrayList<T_cms_role>();
            }
            int tot=_roleService.findAllCount(name,code,modelcode,sitecode);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }


    @RequestMapping("/sysrole/updatestate")
    @ResponseBody
    public ResultMsg updatestate(String id, int state) {
        ResultMsg ret=new ResultMsg();
        try {
            T_cms_role entity =new T_cms_role();
            entity.setId(id);
            entity.setState(new Long(state));
            entity.setModifiedby(getCurrentUser().getUserid());
            int result=_roleService.updateState(entity);
            if(result>0) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/sysrole/getbyid")
    @ResponseBody
    public T_cms_role getbyid(@RequestParam(value = "id") String id){
        T_cms_role entity= _roleService.findbyID(id);
        if(entity==null) {
            entity=new T_cms_role();
            entity.setId(java.util.UUID.randomUUID().toString());
            entity.setState(new Long(1));
            entity.setRoletype(new Long(0));
        }
        return entity;
    }


    @RequestMapping("/sysrole/GetSiteOptions")
    @ResponseBody
    public ArrayList<T_cms_site> GetSiteOptions() {
        ArrayList<T_cms_site> list = new ArrayList<T_cms_site>();
        try {
            list=_siteService.findAllSite("","","","",0,Integer.MAX_VALUE);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/sysrole/GetModelOptions")
    @ResponseBody
    public ArrayList<T_cms_model> GetModelOptions(@RequestParam(value = "sitecode") String sitecode) {
        ArrayList<T_cms_model> list = new ArrayList<T_cms_model>();
        try {
            T_cms_model selective=new T_cms_model();
            selective.setState(new Long(1));
            selective.setSitecode(helper.unescape(sitecode));
            list=_modelService.findBySelective(selective);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/sysrole/save")
    @ResponseBody
    public ResultMsg save(String id, String modelcode, String sitecode, String rolename,String rolecode, int state, int roletype, String remark) {
        ResultMsg ret=new ResultMsg();
        try {
            String userid=getCurrentUser().getUserid();
            T_cms_role entity =_roleService.findbyID(id);
            if(entity==null)
            {
                T_cms_role selective=new T_cms_role();
                selective.setRolecode(helper.unescape(rolecode));
                ArrayList<T_cms_role> chklist=_roleService.findBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    ret.setState(0);
                    ret.setMsg("模块编号已存在");
                    return ret;
                }
                entity=new T_cms_role();
                entity.setId(java.util.UUID.randomUUID().toString());
                entity.setState(new Long(state));
                entity.setCreateby(userid);
                entity.setSitecode(helper.unescape(sitecode));
                entity.setModelcode(helper.unescape(modelcode));
                entity.setRolename(helper.unescape(rolename));
                entity.setRolecode(helper.unescape(rolecode));
                entity.setRoletype(new Long(roletype));
                entity.setRemark(helper.unescape(remark));
                entity.setModifiedby(userid);
                int result=_roleService.insert(entity);
                if(result>0) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
            else
            {
                T_cms_role selective=new T_cms_role();
                selective.setRolecode(helper.unescape(rolecode));
                List<T_cms_role> chklist=_roleService.findBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    long chkcount=chklist.stream().filter(chk -> !chk.getId().equals(id)).count();
                    if(chkcount>0) {
                        ret.setState(0);
                        ret.setMsg("模块编号已存在");
                        return ret;
                    }
                }
                entity.setState(new Long(state));
                entity.setSitecode(helper.unescape(sitecode));
                entity.setModelcode(helper.unescape(modelcode));
                entity.setRolename(helper.unescape(rolename));
                entity.setRolecode(helper.unescape(rolecode));
                entity.setRoletype(new Long(roletype));
                entity.setRemark(helper.unescape(remark));
                entity.setModifiedby(userid);
                int result=_roleService.update(entity);
                if(result>0) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存模板异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }





//{{    UserRole


    @RequestMapping("/sysrole/userlist")
    public ModelAndView userListPage(){
        String rolecode= helper.getParameter("rolecode");
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/SysRoleManage/RoleUserList");
        mod.addObject("username",emp.getUsername());
        mod.addObject("rolecode",rolecode);
        return mod;
    }


    @RequestMapping("/sysrole/adduser")
    public ModelAndView adduser() {
        String rolecode= helper.getParameter("rolecode");
        T_cms_role entity=new T_cms_role();
        entity.setRolecode(helper.unescape(rolecode));
        List<T_cms_role> list=_roleService.findBySelective(entity);
        if(list!=null && list.size()>0)
        {
            entity=list.get(0);
        }
        T_employee emp = getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/SysRoleManage/AddRoleUser");
        mod.addObject("rolecode",rolecode);
        mod.addObject("username",emp.getUsername());
        mod.addObject("role",entity);
        return mod;
    }


//    @RequestMapping("/sysrole/GetAllUserListByRoleCode")
//    @ResponseBody
//    public Result GetUserListByRoleCode(String name, String code,String rolecode, int draw, int start, int length) {
//        //region 获取排序字段
//        String orderdata = GetOrderdata();
//        String orderdir = GetOrderdir();
//        //endregion
//        int begin=start==0?start:start+1;
//        int end=start==0?start+length:start+length;
//        Result res=new Result();
//        name= helper.unescape(name);
//        code= helper.unescape(code);
//        rolecode=helper.unescape(rolecode);
//        ArrayList<T_cms_roleuser> list = new ArrayList<T_cms_roleuser>();
//        try {
//            list=_roleUserService.findAllEmpPagerByRoleCode(name,code,rolecode,orderdata,orderdir,begin,end);
//            int tot=_roleUserService.findAllEmpCountByRoleCode(name,code,rolecode);
//            res.setdata(list);
//            res.setdraw(draw);
//            res.setrecordsFiltered(tot);
//            res.setrecordsTotal(tot);
//        } catch (Exception ex) {
//            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
//        }
//        return res;
//    }

    @RequestMapping("/sysrole/GetAllUserList")
    @ResponseBody
    public Result GetUserList(String name, String code,String rolecode, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start==0?start:start+1;
        int end=start==0?start+length:start+length;
        Result res=new Result();
        name= helper.unescape(name);
        code= helper.unescape(code);
        rolecode=helper.unescape(rolecode);
        ArrayList<T_cms_roleuser> list = new ArrayList<T_cms_roleuser>();
        try {
            list=_roleUserService.findAllPager(name,code,rolecode,orderdata,orderdir,begin,end);
            int tot=_roleUserService.findAllCount(name,code,rolecode);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }


    @RequestMapping("/sysrole/getEmpListByRoleCode")
    @ResponseBody
    public ArrayList<T_cms_roleuser> getemplist(String user,String rolecode) {
        ArrayList<T_cms_roleuser> list = new ArrayList<T_cms_roleuser>();
        user = helper.unescape(user);
        rolecode=helper.unescape(rolecode);
        try {
            list = _roleUserService.findEmpByRoleCode(user,rolecode);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }


//    @RequestMapping("/sysrole/saveroleuser")
//    @ResponseBody
//    public ResultMsg saveRoleUser(String rolecode,String addusers,String delusers)
//    {
//        boolean result=true;
//        ResultMsg ret=new ResultMsg();
//        String userid=getCurrentUser().getUserid();
//        try {
//            if(delusers!=null && !delusers.equals(""))
//            {
//                List<String> delresult = Arrays.asList(delusers.split(","));
//                List<T_cms_roleuser> dellist=new ArrayList<T_cms_roleuser>();
//                for(String uid:delresult)
//                {
//                    if(!uid.equals(""))
//                    {
//                        T_cms_roleuser entity=new T_cms_roleuser();
//                        entity.setRolecode(helper.unescape(rolecode));
//                        entity.setUserid(uid);
//                        entity.setState(new Long(0));
//                        entity.setModifiedby(userid);
//                        dellist.add(entity);
//                    }
//                }
//                if(dellist.size()>0) {
//                    int size=100;
//                    if(dellist.size()<=size) {
//                        result &= _roleUserService.updateByBatch(dellist) > 0;
//                    }
//                    else
//                    {
//                        int page=dellist.size()%size==0?dellist.size()/size:(dellist.size()/size)+1;
//                        int begin=0;
//                        int end=size;
//                        for(int i=0;i<page;i++)
//                        {
//                            result &= _roleUserService.updateByBatch(dellist.subList(begin,(end>dellist.size()?dellist.size():end))) > 0;
//                            begin += size;
//                            end = begin + size;
//                        }
//                    }
//                }
//            }
//            if(addusers!=null && !addusers.equals(""))
//            {
//                List<String> addresult = Arrays.asList(addusers.split(","));
//                List<T_cms_roleuser> addlist=new ArrayList<T_cms_roleuser>();
//                for(String uid:addresult)
//                {
//                    if(!uid.equals(""))
//                    {
//                        T_cms_roleuser entity=new T_cms_roleuser();
//                        entity.setId(java.util.UUID.randomUUID().toString());
//                        entity.setRolecode(helper.unescape(rolecode));
//                        entity.setUserid(uid);
//                        entity.setState(new Long(1));
//                        entity.setCreateby(userid);
//                        entity.setModifiedby(userid);
//                        addlist.add(entity);
//                    }
//                }
//                if(addlist.size()>0) {
//                    int size=100;
//                    if(addlist.size()<=size) {
//                        result &= _roleUserService.insertByBatch(addlist) > 0;
//                    }
//                    else
//                    {
//                        int page=addlist.size()%size==0?addlist.size()/size:(addlist.size()/size)+1;
//                        int begin=0;
//                        int end=size;
//                        for(int i=0;i<page;i++)
//                        {
//                            result &= _roleUserService.insertByBatch(addlist.subList(begin,(end>addlist.size()?addlist.size():end))) > 0;
//                            begin += size;
//                            end = begin + size;
//                        }
//                    }
//                }
//            }
//            if(result) {
//                ret.setState(1);
//                ret.setMsg("保存成功");
//            }
//            else
//            {
//                ret.setState(0);
//                ret.setMsg("保存失败");
//            }
//        } catch (Exception ex) {
//            ret.setState(0);
//            ret.setMsg("保存失败");
//            LoggerHelper.error("保存角色人员异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
//        }
//        return ret;
//    }


    @RequestMapping("/sysrole/saveroleuser")
    @ResponseBody
    public ResultMsg saveRoleUser(String rolecode,String uid)
    {
        boolean result=true;
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {

            if(rolecode!=null && !rolecode.equals("") && uid!=null && !uid.equals("")) {
                T_cms_roleuser entity = new T_cms_roleuser();
                entity.setRolecode(helper.unescape(rolecode));
                entity.setUserid(helper.unescape(uid));
                entity.setState(new Long(1));
                ArrayList<T_cms_roleuser> chklist=  _roleUserService.findBySelective(entity);
                if(chklist!=null && chklist.size()>0)
                {
                    ret.setState(0);
                    ret.setMsg("人员已存在");
                    return ret;
                }
                entity.setId(java.util.UUID.randomUUID().toString());
                entity.setCreateby(userid);
                entity.setModifiedby(userid);
                result = _roleUserService.insert(entity)>0;
                if (result) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败，参数错误。");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存角色人员异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }


    @RequestMapping("/sysrole/delroleuser")
    @ResponseBody
    public ResultMsg delRoleUser(String rolecode,String uid)
    {
        boolean result=true;
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {

            if(rolecode!=null && !rolecode.equals("") && uid!=null && !uid.equals("")) {
                result=_roleUserService.delete(helper.unescape(uid),helper.unescape(rolecode))>0;
                if(result)
                {
                    ret.setState(1);
                    ret.setMsg("删除成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            }
            else
            {
                ret.setState(0);
                ret.setMsg("删除失败，参数错误。");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("删除角色的人员异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }




//}}





    //{{  RoleDept


    @RequestMapping("/sysrole/deptlist")
    public ModelAndView deptListPage(){
        String rolecode= helper.getParameter("rolecode");
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/SysRoleManage/RoleDeptList");
        mod.addObject("username",emp.getUsername());
        mod.addObject("rolecode",rolecode);
        return mod;
    }


    @RequestMapping("/sysrole/GetAllDeptTreeByRoleCode")
    @ResponseBody
    public List<EasyTreeNode> GetAllDeptTreeByRoleCode(String code) {
        List<EasyTreeNode> tree = new ArrayList<EasyTreeNode>();
        String rootDeptID = "00000001";
        EasyTreeNode root = _roleDeptService.GetEasyTreeByRoleCode(rootDeptID,helper.unescape(code));
        tree.add(root);
        return tree;
    }


    @RequestMapping("/sysrole/saveroledept")
    @ResponseBody
    public ResultMsg saveRoleDept(String rolecode,String deptids)
    {
        boolean result=true;
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {
            T_cms_roledept upentity=new T_cms_roledept();
            upentity.setRolecode(helper.unescape(rolecode));
            upentity.setState(new Long(0));
            upentity.setModifiedby(userid);
            _roleDeptService.updateStateByRoleCode(upentity);
            if(deptids!=null && !deptids.equals(""))
            {
                List<String> addresult = Arrays.asList(deptids.split(","));
                List<T_cms_roledept> addlist=new ArrayList<T_cms_roledept>();
                for(String did:addresult)
                {
                    if(!did.equals(""))
                    {
                        T_cms_roledept entity=new T_cms_roledept();
                        entity.setId(java.util.UUID.randomUUID().toString());
                        entity.setRolecode(helper.unescape(rolecode));
                        entity.setDeptid(did);
                        entity.setState(new Long(1));
                        entity.setCreateby(userid);
                        entity.setModifiedby(userid);
                        addlist.add(entity);
                    }
                }
                if(addlist.size()>0) {
                    int size=100;
                    if(addlist.size()<=size) {
                        result &= _roleDeptService.insertByBatch(addlist) > 0;
                    }
                    else
                    {
                        int page=addlist.size()%size==0?addlist.size()/size:(addlist.size()/size)+1;
                        int begin=0;
                        int end=size;
                        for(int i=0;i<page;i++)
                        {
                            result &= _roleDeptService.insertByBatch(addlist.subList(begin,(end>addlist.size()?addlist.size():end))) > 0;
                            begin += size;
                            end = begin + size;
                        }
                    }
                }
            }
            if(result) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存角色部门异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }



    //}}




//{{        RoleLink


    @RequestMapping("/sysrole/linklist")
    public ModelAndView linkListPage(){
        String rolecode= helper.getParameter("rolecode");
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/SysRoleManage/RoleLinkList");
        mod.addObject("username",emp.getUsername());
        mod.addObject("rolecode",rolecode);
        mod.addObject("rolemodeltype",_roleService.findRoleModeTypeByRoleCode(rolecode));
        return mod;
    }

    @RequestMapping("/sysrole/GetAllLinkTreeByRoleCode")
    @ResponseBody
    public List<EasyTreeNode> GetAllLinkTreeByRoleCode(String code) {
        List<EasyTreeNode> tree = new ArrayList<EasyTreeNode>();
        T_cms_role selective=new T_cms_role();
        selective.setRolecode(helper.unescape(code));
        List<T_cms_role> list= _roleService.findBySelective(selective);
        if(list!=null && list.size()>0) {
            EasyTreeNode root = _roleLinkService.GetEasyTreeByRoleCode(list.get(0).getSitecode(),list.get(0).getModelcode(), list.get(0).getRolecode());
            tree.addAll(root.getchildren());
        }
        return tree;
    }



    @RequestMapping("/sysrole/saverolelink")
    @ResponseBody
    public ResultMsg saveRoleLink(String rolecode,String navlinkids)
    {
        boolean result=true;
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {
            T_cms_navlinkrole upentity=new T_cms_navlinkrole();
            upentity.setRolecode(helper.unescape(rolecode));
            upentity.setState(new Long(0));
            upentity.setModifiedby(userid);
            _roleLinkService.updateStateBySelective(upentity);
            if(navlinkids!=null && !navlinkids.equals(""))
            {
                List<String> addresult = Arrays.asList(navlinkids.split(","));
                List<T_cms_navlinkrole> addlist=new ArrayList<T_cms_navlinkrole>();
                for(String lid:addresult)
                {
                    if(!lid.equals(""))
                    {
                        T_cms_navlinkrole entity=new T_cms_navlinkrole();
                        entity.setId(java.util.UUID.randomUUID().toString());
                        entity.setRolecode(helper.unescape(rolecode));
                        entity.setNavlinkid(lid);
                        entity.setState(new Long(1));
                        entity.setCreateby(userid);
                        entity.setModifiedby(userid);
                        addlist.add(entity);
                    }
                }
                if(addlist.size()>0) {
                    int size=100;
                    if(addlist.size()<=size) {
                        result &= _roleLinkService.insertByBatch(addlist) > 0;
                    }
                    else
                    {
                        int page=addlist.size()%size==0?addlist.size()/size:(addlist.size()/size)+1;
                        int begin=0;
                        int end=size;
                        for(int i=0;i<page;i++)
                        {
                            result &= _roleLinkService.insertByBatch(addlist.subList(begin,(end>addlist.size()?addlist.size():end))) > 0;
                            begin += size;
                            end = begin + size;
                        }
                    }
                }
            }
            if(result) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存角色链接异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }



    //}}







}
