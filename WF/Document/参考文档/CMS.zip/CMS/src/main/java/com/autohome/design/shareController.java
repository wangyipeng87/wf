package com.autohome.design;

import com.autohome.cms.Entity.T_cms_datadictionary;
import com.autohome.cms.controller.baseController;
import com.autohome.cms.service.ContentService;
import com.autohome.common.*;
import com.autohome.design.service.IDesignAddressService;
import com.autohome.design.service.IDesignRuleService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.sql.Timestamp;
import java.util.ArrayList;

/**
 * Created by Administrator on 2017/8/2.
 */
@Controller
@RequestMapping(value = "/Share")
public class shareController extends baseController {

    @Value("#{configProperties['ShareChannelID']}")
    private String ShareChannelID;
    @Autowired
    IDesignRuleService designRuleService;
    @Autowired
    IDesignAddressService designAddressService;
    @Resource
    ContentService _contentService;

    private ArrayList<T_cms_datadictionary> belongGroup;

    private void initdata() {
        belongGroup = designRuleService.findtypebycode(DataDictionaryType.BelongGroup);
    }

    @RequestMapping("/ShareList")
    public ModelAndView showHomePage() {
        ModelAndView mod = new ModelAndView("jsps/Design/ShareManage/ShareList");
        initdata();
        mod.addObject("BelongGroup", belongGroup);
        return mod;
    }

    @RequestMapping("/AddShare")
    public ModelAndView AddRule() {
        ModelAndView mod = new ModelAndView("jsps/Design/ShareManage/AddShare");
        initdata();
        mod.addObject("BelongGroup", belongGroup);
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        mod.addObject("id", id);
        mod.addObject("emp", getCurrentUser());
        return mod;
    }
    @RequestMapping("/updateDownload")
    @ResponseBody
    public int updateDownload(String id) {
        try {
            _contentService.updatedownLoadnum(id);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }
    @RequestMapping("/getAddress")
    @ResponseBody
    public ArrayList<T_design_address> GetFileList(String code) {
        ArrayList<T_design_address> list = new ArrayList<T_design_address>();
        try {
            list = designAddressService.findAllByContentid(code);
            if (list == null || list.size() == 0) {
                list = new ArrayList<T_design_address>();
            }

        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }
    @RequestMapping("/getbyid")
    @ResponseBody
    public T_design_rule getbyid(@RequestParam(value = "id") String id) {
        T_design_rule entity = designRuleService.findbyid(id);
        if (entity == null) {
            entity = new T_design_rule();
            entity.setid(java.util.UUID.randomUUID().toString());
            entity.setstate(1);
            entity.setisdelete(0);
            entity.setcreatedby(getCurrentUser().getUserid());
            entity.setcreateusercode(getCurrentUser().getUsercode());
            entity.setcreateusername(getCurrentUser().getUsername());
            entity.setparentcode(this.ShareChannelID);
            entity.setchannelcode(this.ShareChannelID);
            entity.setType("");
            entity.setLeave("");
            entity.setRange("");
        }
        return entity;
    }

    @RequestMapping("/save")
    @ResponseBody
    public int SaveRule(String jsonString) {
        int i = 1;
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            T_design_rule entity = gson.fromJson(jsonString, T_design_rule.class);
            T_design_rule form = designRuleService.findbyid(entity.getid());
            if (form == null) {
                entity.setcreatedby(getCurrentUser().getUserid());
                entity.setmodifiedby(getCurrentUser().getUserid());
            } else {
                entity.setmodifiedby(getCurrentUser().getUserid());
            }
            entity.setisstatic(0);
            if (entity.getprocessstate() != null && entity.getprocessstate().equals("Release")) {
                if (entity.getpublishtime() == null) {
                    entity.setpublishtime(new Timestamp(System.currentTimeMillis()));
                }
            }
            entity.setisdelete(0);
            entity.setsitecode("");
            designRuleService.save(entity);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/GetShareList")
    @ResponseBody
    public Result GetRuleList(String title, String groupid, String leave, String range, String type, int state, String processstate, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        title = helper.unescape(title);
        ArrayList<T_design_rule> list = new ArrayList<T_design_rule>();
        try {
            list = designRuleService.findall(this.ShareChannelID, title, groupid, leave, range, type, state,processstate, orderdata, orderdir, begin, end);
            int tot = designRuleService.findallCount(this.ShareChannelID, title, groupid, leave, range, type, state,processstate, orderdata, orderdir);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_design_rule>();
            }
            initdata();
            for (int i = 0; i < list.size(); i++) {
                list.get(i).setgroupName(GetDataDictionary(DataDictionaryType.BelongGroup, list.get(i).getGroupid()));
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询规范库列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    private String GetDataDictionary(String typecode, String ids) {
        if (typecode == null || typecode.equals("") || ids == null || ids.equals("")) {
            return "";
        }
        ArrayList<T_cms_datadictionary> list = new ArrayList<T_cms_datadictionary>();
        switch (typecode) {
            case DataDictionaryType.BelongGroup:
                list = this.belongGroup;
                break;
            default:
                list = new ArrayList<T_cms_datadictionary>();
                break;
        }
        String str = "";
        String[] idlist = ids.split(",");
        for (int i = 0; i < idlist.length; i++) {
            for (int j = 0; j < list.size(); j++) {
                if (list.get(j).getCode() == Integer.parseInt(idlist[i])) {
                    str = str + list.get(j).getName() + ",";
                }
            }
        }
        if (!str.equals("") && str.lastIndexOf(",") == str.length() - 1) {
            str = str.substring(0, str.length() - 1);
        }
        return str;
    }
}
