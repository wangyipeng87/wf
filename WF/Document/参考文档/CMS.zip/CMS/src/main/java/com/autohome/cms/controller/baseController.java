package com.autohome.cms.controller;

import com.autohome.cms.Entity.T_employee;
import com.autohome.cms.service.EmployeeService;
import org.jasig.cas.client.authentication.AttributePrincipal;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * Created by Administrator on 2017/5/15.
 */
@Controller
public class baseController {
    @Value("#{configProperties['TestUserCode']}")
    private String TestUserCode;
    @Value("#{configProperties['IsTest']}")
    private String IsTest;
    //调用员工头像接口的url
    @Value("#{configProperties['imgurl']}")
    public String imgurl;
    //调用员工头像接口的url
    @Value("#{configProperties['OWAURL']}")
    public String OWAURL;
    //调用员工头像接口的url
    @Value("#{configProperties['OWAAccount']}")
    public String OWAAccount;

    @Resource
    EmployeeService _employeeService;

    protected T_employee getCurrentUser() {
        T_employee emp = null;
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        if (request.getSession().getAttribute("emp") != null) {
            emp = (T_employee) _employeeService.findByUserAccount((String) request.getSession().getAttribute("emp"));
        } else {
            AttributePrincipal principal = (AttributePrincipal) request.getUserPrincipal();
            String username = principal.getName();
            emp = (T_employee) _employeeService.findByUserAccount(username);
            if (emp == null) {
                if (this.IsTest.equals("1")) {
                    emp = _employeeService.findByUserCode(this.TestUserCode);
                }
            }
        }
        if (emp != null) {
            request.getSession().setAttribute("emp", emp.getAccountname());
        } else {
            emp = new T_employee();
            emp.setUsercode("-1");
        }
        return emp;
    }

    public String GetOrderdata() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        if (!request.getParameter("order[0][column]").equals(null) && !request.getParameter("order[0][column]").equals("")) {
            String ind = request.getParameter("order[0][column]");
            return request.getParameter("columns[" + ind + "][data]").toLowerCase();
        }
        return "";
    }

    public boolean issuper() {
       if(_employeeService.issuperuser(getCurrentUser().getUserid())>0)
           return  true;
        return false;
    }


    public String GetOrderdir() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        if (!request.getParameter("order[0][column]").equals(null) && !request.getParameter("order[0][column]").equals("")) {
            String ind = request.getParameter("order[0][column]");
            return request.getParameter("order[0][dir]").toLowerCase();
        }
        return "";
    }

}
