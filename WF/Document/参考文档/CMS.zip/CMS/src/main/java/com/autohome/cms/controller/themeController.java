package com.autohome.cms.controller;

import com.autohome.cms.Entity.*;
import com.autohome.cms.common.CmnFunction;
import com.autohome.cms.service.ContentService;
import com.autohome.cms.service.ThemeContentService;
import com.autohome.cms.service.ThemeService;
import com.autohome.common.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Administrator on 2017/6/5.
 */
@Controller
public class themeController extends baseController {

    @Resource
    ThemeService _themeService;
    @Resource
    ThemeContentService _themeContentService;
    @Resource
    ContentService _contentService;
    //焦点图
//    @Value("#{configProperties['FocusMap']}")
//    private String FocusMap;
    //通知公告
//    @Value("#{configProperties['Notices']}")
//    private String Notices;

    @RequestMapping("/theme/list")
    public ModelAndView themelist() {
        ModelAndView mod = new ModelAndView("jsps/CMS/ThemeManage/themeList");
        mod.addObject("issuper", issuper() ? 1 : 0);
        LoggerHelper.info("asdsa");
        return mod;
    }

    @RequestMapping("/theme/publishcontent")
    public ModelAndView publishContent() {
        ModelAndView mod = new ModelAndView("jsps/CMS/ThemeManage/publishContent");
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        String themeid = helper.getParameter("themeid");
        if (themeid == null || themeid.equals("")) {
            themeid = java.util.UUID.randomUUID().toString();
        }
        String from = helper.getParameter("from");

        T_cms_theme theme = _themeService.findThemebyID(themeid);

        T_employee emp = getCurrentUser();
        mod.addObject("id", id);
        mod.addObject("themeid", themeid);
        mod.addObject("from", from);
        if (theme != null) {
            mod.addObject("themename", theme.gettitle());
        } else {
            mod.addObject("themename", "");
        }
        LoggerHelper.info("asdsa");
        return mod;
    }

    @RequestMapping("/theme/GetAllList")
    @ResponseBody
    public Result GetList(String title, int state, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        title = helper.unescape(title);
        ArrayList<T_cms_theme> list = new ArrayList<T_cms_theme>();
        try {
            list = _themeService.findAllTheme(issuper() ? 1 : 0, title, state, "", getCurrentUser().getUsercode(), orderdata, orderdir, begin, end);
            int tot = _themeService.findAllThemeCount(issuper() ? 1 : 0, title, state, "", getCurrentUser().getUsercode(), orderdata, orderdir);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/theme/GetAllListForAddRole")
    @ResponseBody
    public ArrayList<T_cms_theme> GetList() {

        ArrayList<T_cms_theme> list = new ArrayList<T_cms_theme>();
        try {
            list = _themeService.findAllForRoleAdd();

        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/theme/GetMaxQi")
    @ResponseBody
    public int GetMaxQi(String themeid) {
        int i = 1;
        try {
            i = _themeContentService.getmaxqi(themeid);
            i = i + 1;
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    //themeAdd
    @RequestMapping("/theme/add")
    public ModelAndView add() {
        String id = helper.getParameter("id");
        String themeid = helper.getParameter("themeid");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        ModelAndView mod = new ModelAndView("jsps/CMS/ThemeManage/themeAdd");
        mod.addObject("id", id);
        return mod;
    }

    @RequestMapping("/theme/getbyid")
    @ResponseBody
    public T_cms_theme getbyid(@RequestParam(value = "id") String id) {
        T_cms_theme entity = _themeService.findThemebyID(id);
        if (entity == null) {
            entity = new T_cms_theme();
            entity.setid(java.util.UUID.randomUUID().toString());
            entity.setstate(new Long(1));
            entity.setorder(new Long(1));
            entity.setorder(_themeService.getmaxqi()+1);
        }
        return entity;
    }

    @RequestMapping("/theme/getcontentbyid")
    @ResponseBody
    public T_cms_themecontent getcontentbyid(@RequestParam(value = "id") String id,@RequestParam(value = "themeid") String themeid) {
        T_cms_themecontent entity = _themeContentService.findbyid(id);
        if (entity == null) {
            Calendar now = Calendar.getInstance();
            entity = new T_cms_themecontent();
            entity.setid(java.util.UUID.randomUUID().toString());
            entity.setstate(1);
            entity.setisstatic(0);
            entity.setyear(now.get(Calendar.YEAR));
            entity.setperiods(_themeContentService.getmaxqi(themeid)+1);
        }
        return entity;
    }

    @RequestMapping("/theme/savetheme")
    @ResponseBody
    public int savetheme(String id, String title, String logourl, String logopath, String department, String common, int state, int order) {
        try {
            T_cms_theme entity = new T_cms_theme();
            entity = _themeService.findThemebyID(id);
            if (entity == null) {
                entity = new T_cms_theme();
                entity.setid(java.util.UUID.randomUUID().toString());
            }
            entity.setstate(new Long(state));
            entity.setcreateusercode(getCurrentUser().getUsercode());
            entity.setlogourl(helper.unescape(logourl));
            entity.setorder(order);
            entity.setsitecode("");
            entity.settitle(helper.unescape(title));
            entity.setlogopath(helper.unescape(logopath));
            entity.setupdateusercode(getCurrentUser().getUsercode());
            entity.setcommon(helper.unescape(common));
            entity.setdepartment(helper.unescape(department));
            _themeService.saveTheme(entity);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/theme/updatetheme")
    @ResponseBody
    public int updatetheme(String id, int state) {
        int i = 1;
        try {
            _themeService.update(id, state);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/theme/updateorder")
    @ResponseBody
    public int updateorder(String id, int order) {
        int i = 1;
        try {
            T_cms_theme entity = _themeService.findThemebyID(id);
            _themeService.updateorder(id, (int) entity.getorder(), order);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/theme/isPeriods")
    @ResponseBody
    public int isPeriods(String themeid, int year, int periods, String id) {
        int i = 1;
        try {
            return _themeContentService.isPeriods(themeid, year, periods, id);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/theme/isorder")
    @ResponseBody
    public int isorder(String id, int order) {
        int i = 1;
        try {
            return _themeService.isorder(id, order);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/theme/savecontent")
    @ResponseBody
    public int SaveContent(String jsonString) {
        int i = 1;
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            T_cms_themecontent entity = gson.fromJson(jsonString, T_cms_themecontent.class);
            T_cms_themecontent form = _themeContentService.findbyid(entity.getid());
            if (form == null) {
               // entity.setid(java.util.UUID.randomUUID().toString());
                entity.setcreatedby(getCurrentUser().getUserid());
                entity.setmodifiedby(getCurrentUser().getUserid());
            } else {
                entity.setmodifiedby(getCurrentUser().getUserid());
            }
            entity.setisdelete(0);
            entity.setsitecode("");
            if (entity.getcontents() != null && !entity.getcontents().equals("")) {
                entity.setcontenttext(helper.getTextFromHtml(entity.getcontents()));
            }
            entity.setisstatic(0);
            if (entity.getprocessstate() != null && entity.getprocessstate().equals("Release")) {
                if (entity.getpublishtime() == null) {
                    entity.setpublishtime(new Timestamp(System.currentTimeMillis()));
                }
            }
            if (form == null) {
                if (_themeContentService.Add(entity)) {
                    i = 1;
                } else {
                    i = 0;
                }
            } else {
                if (_themeContentService.Updatethemecontent(entity)) {
                    i = 1;
                } else {
                    i = 0;
                }
            }
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/theme/contentlist")
    public ModelAndView contentlist() {
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        ModelAndView mod = new ModelAndView("jsps/CMS/ThemeManage/contentList");
        mod.addObject("id", id);
        return mod;
    }


    @RequestMapping("/theme/updatethemeContent")
    @ResponseBody
    public int updatethemeContent(String id, int state) {
        int i = 1;
        try {
            _themeContentService.update(id, state);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/theme/updatePeriods")
    @ResponseBody
    public int updatePeriods(String id, int periods) {
        int i = 1;
        try {
            T_cms_themecontent entity = _themeContentService.findbyid(id);
            _themeContentService.updateyear(entity.getthemeid(), id, entity.getyear() == null ? 0 : entity.getyear(), periods, entity.getperiods() == null ? 0 : entity.getperiods());
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/theme/updateyear")
    @ResponseBody
    public int updateyear(String id, int year) {
        int i = 1;
        try {
            T_cms_themecontent entity = _themeContentService.findbyid(id);
            _themeContentService.updateyear(entity.getthemeid(), id, year, entity.getperiods() == null ? 0 : entity.getperiods(), entity.getperiods() == null ? 0 : entity.getperiods());
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }


    @RequestMapping("/theme/Getcontentlist")
    @ResponseBody
    public Result GetContentList(String title, int state, String themeid, int year, int periods, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        title = helper.unescape(title);
        themeid = helper.unescape(themeid);
        ArrayList<T_cms_themecontent> list = new ArrayList<T_cms_themecontent>();
        try {
            list = _themeContentService.findbythemeid(themeid, "", state, title, year, periods,"", begin, end);
            int tot = _themeContentService.findCountbythemeid(themeid, "", state, title, year, periods,"");
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }
    @RequestMapping("/theme/checkenable")
    @ResponseBody
    public String checkenable(@RequestParam(value = "id") String id) {
        String mess = "";
        T_cms_themecontent entity = _themeContentService.findbyid(id);

        if (entity.getcontenttitle() == null || entity.getcontenttitle().equals("")) {
            mess = mess + "请填写标题<br/>";
        }
        if (entity.getsummary() == null || entity.getsummary().equals("")) {
            mess = mess + "请填写简介<br/>";
        }

        if (entity.getyear() == null||entity.getperiods() == null  ) {
            mess = mess + "请填写期数";
        }


        return helper.escape(mess);
    }
    @RequestMapping("/theme/getPeriods")
    @ResponseBody
    public ArrayList<T_cms_themecontent> getPeriods(String themeid, int year) {
        ArrayList<T_cms_themecontent> list = new ArrayList<T_cms_themecontent>();
        try {
            list = _themeContentService.getPeriods(themeid, year);
        } catch (Exception ex) {
            list = new ArrayList<T_cms_themecontent>();
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/theme/getYear")
    @ResponseBody
    public ArrayList<T_cms_themecontent> getYear(String themeid) {
        ArrayList<T_cms_themecontent> list = new ArrayList<T_cms_themecontent>();
        try {
            list = _themeContentService.getYear(themeid);
        } catch (Exception ex) {
            list = new ArrayList<T_cms_themecontent>();
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }
    @RequestMapping("/theme/del")
    @ResponseBody
    public ResultMsg delbyid(@RequestParam(value = "id") String id) {
        ResultMsg ret = new ResultMsg();
        String userid = getCurrentUser().getUserid();
        Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        try {
            if (id != null && !id.equals("")) {
                T_cms_themecontent item = _themeContentService.findbyid(id);
                String beforeContent=gson.toJson(item);
                item.setisdelete(1);//0未删除 1已删除
                boolean result=_themeContentService.deleteList(id,getCurrentUser());
                if (result) {
                    ret.setState(1);
                    ret.setMsg("删除成功");
                    //插入操作日志
                    CmnFunction.InsertOperationLog(item.getsitecode(), OperationType.Update,FormType.T_CMS_ThemeContent,item.getid(),beforeContent,gson.toJson(item));
                } else {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            } else {
                ret.setState(0);
                ret.setMsg("没有要删除的行");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/theme/dellist")
    @ResponseBody
    public ResultMsg delListByIds(@RequestParam(value = "ids") String ids) {
        ResultMsg ret = new ResultMsg();
        T_employee user = getCurrentUser();
        try {
            if (ids != null && ids.length() > 0) {
                boolean result=_themeContentService.deleteList(ids,user);
                if (result) {
                    ret.setState(1);
                    ret.setMsg("删除成功");
                } else {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            } else {
                ret.setState(0);
                ret.setMsg("没有要删除的行");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("批量删除文章操作异常，操作人:" + user.getUsername() + "(" + user.getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

}
