package com.autohome.cms.controller;

import com.autohome.cms.Entity.*;
import com.autohome.cms.common.CmnFunction;
import com.autohome.cms.service.*;
import com.autohome.common.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/6/13.
 */
@Controller
public class knowledgeController extends baseController {

    @Resource
    ContentService _contentService;
    @Resource
    ChannelService _channelService;
    @Resource
    DeptinfoService _deptinfoService;
    @Resource
    ContentFileService _contentFileService;
    @Resource
    KnowledgeformService _knowledgeformService;
    @Resource
    KnowledgeFileService _knowledgeFileService;
    @Resource
    KnowledgedepartService _knowledgedepartService;
    @Resource
    EmployeeService _employeeService;
    @Resource
    KnowledgeuserService _knowledgeuserService;
    @Resource
    CommoninfoService _commoninfoservice;

    @RequestMapping("/knowledge/knowledgeList")
    public ModelAndView showHomePage() {
        // Model model=new Model() ;
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeManage/knowledgeList");
        return mod;
    }

    @RequestMapping("/knowledge/GetList")
    @ResponseBody
    public Result GetList(String parentid, String catalogid, String title, int state, String createusername, String begindate, String enddate, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        catalogid = helper.unescape(catalogid);
        if (catalogid == null || catalogid.equals("")) {
            catalogid = "00000000-0000-0000-0000-000000000000";
        }
        title = helper.unescape(title);
        createusername = helper.unescape(createusername);
        if (begindate != null && !begindate.equals("")) {
            begindate = helper.unescape(begindate) + " 00:00:00";
        }
        if (enddate != null && !enddate.equals("")) {
            enddate = helper.unescape(enddate) + " 23:59:59";
        }
        ArrayList<content> list = new ArrayList<content>();
        try {
            list = _knowledgeformService.findcontent(-1, "knowledge", parentid, catalogid, title, state, createusername, getCurrentUser().getUsercode(), "", begindate, enddate, orderdata, orderdir, begin, end);
            int tot = _knowledgeformService.findcontentCount(-1, "knowledge", parentid, catalogid, title, state, createusername, getCurrentUser().getUsercode(), "", begindate, enddate);
            if (list == null && list.size() == 0) {
                list = new ArrayList<content>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/knowledge/updatestate")
    @ResponseBody
    public int updatestate(String id, int state) {
        try {
            _contentService.UpdateState(id, state);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/knowledge/add")
    public ModelAndView add() {
        String id = helper.getParameter("id");
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeManage/knowledgeAdd");
//        mod.addObject("isnew", 0);
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
//            mod.addObject("isnew", 1);
        }
        T_employee emp = getCurrentUser();
        mod.addObject("id", id);
        mod.addObject("OWAAccount", this.OWAAccount);
        mod.addObject("OWAURL", this.OWAURL);

        return mod;
    }

    @RequestMapping("/knowledge/getbyid")
    @ResponseBody
    public T_cms_knowledgeform getknowledgebyid(@RequestParam(value = "id") String id) {
        T_cms_knowledgeform entity = _knowledgeformService.findByID(id);
        if (entity == null) {
            entity = new T_cms_knowledgeform();
            entity.setId(java.util.UUID.randomUUID().toString());
            entity.setState(1);
            entity.setisnew(1);
        } else {
            entity.setisnew(0);
        }
        entity.setformtype("knowledge");
        return entity;
    }

    @RequestMapping("/knowledge/checkenable")
    @ResponseBody
    public String checkenable(@RequestParam(value = "id") String id) {
        String mess = "";
        T_cms_knowledgeform entity = _knowledgeformService.findByID(id);
        if (entity.getParentcode() == null || entity.getParentcode().equals("")) {
            mess = mess + "请选择一级栏目<br/>";
        }
        if (entity.getKnowledgetitle() == null || entity.getKnowledgetitle().equals("")) {
            mess = mess + "请填写标题<br/>";
        }
        return helper.escape(mess);
    }
    @RequestMapping("/knowledge/GetFileList")
    @ResponseBody
    public ArrayList<T_cms_knowledgefile> GetknowledgeFileList(String code) {
        ArrayList<T_cms_knowledgefile> list = new ArrayList<T_cms_knowledgefile>();
        try {
            list = _knowledgeFileService.findByKnowledgeID(code);
            if (list == null || list.size() == 0) {
                list = new ArrayList<T_cms_knowledgefile>();
            }
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/knowledge/save")
    @ResponseBody
    public int SaveKnowledge(String jsonString) {
        int i = 1;
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            T_cms_knowledgeform entity = gson.fromJson(jsonString, T_cms_knowledgeform.class);
            T_cms_knowledgeform form = _knowledgeformService.findByID(entity.getId());
            if (form == null) {
                //entity.setId(java.util.UUID.randomUUID().toString());
                entity.setCreatedby(getCurrentUser().getUserid());
                entity.setModifiedby(getCurrentUser().getUserid());
            } else {
                entity.setModifiedby(getCurrentUser().getUserid());
            }
            if (entity.getprocessstate() != null && entity.getprocessstate().equals("Release")) {
                if (entity.getpublishtime() == null) {
                    entity.setpublishtime(new Timestamp(System.currentTimeMillis()));
                }
            }
            entity.setisdelete(0);
            entity.setSitecode("");
            _knowledgeformService.save(entity);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/knowledge/getknowledgedepinfo")
    @ResponseBody
    public List<T_cms_knowledgedepart> getdepinfoall(String id) {
        List<T_cms_knowledgedepart> list = _knowledgedepartService.getDeptByFormid(id);
        return list;
    }

    @RequestMapping("/knowledge/getknowledgeuser")
    @ResponseBody
    public List<T_cms_knowledgeuser> getknowledgeuser(String id) {
        List<T_cms_knowledgeuser> list = _knowledgeuserService.getUserByFormid(id);
        return list;
    }

    @RequestMapping("/knowledge/getdepinfoall")
    @ResponseBody
    public List<EasyTreeNode> getdepinfoall() {
        List<EasyTreeNode> tree = new ArrayList<EasyTreeNode>();
        String rootCode = "00000001";
        EasyTreeNode root = _deptinfoService.GetEasyTreeByRootCode(rootCode);
        tree.add(root);
        return tree;
    }
    //_knowledgedepartService

    @RequestMapping("/knowledge/commoninfo")
    public ModelAndView commoninfo() {
        // Model model=new Model() ;
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeManage/commonInfo");
        return mod;
    }

    @RequestMapping("/knowledge/getCommoninfo")
    @ResponseBody
    public Result getCommoninfo(String parentid, String catalogid, String title, int state, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        catalogid = helper.unescape(catalogid);
        if (catalogid == null || catalogid.equals("")) {
            catalogid = "00000000-0000-0000-0000-000000000000";
        }
        title = helper.unescape(title);

        ArrayList<T_cms_commoninfo> list = new ArrayList<T_cms_commoninfo>();
        try {
            list = _commoninfoservice.findcommoninfo(catalogid, parentid, title, state, orderdata, orderdir, begin, end);
            int tot = _commoninfoservice.findcommoninfocount(catalogid, parentid, title, state, orderdata, orderdir);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_cms_commoninfo>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/knowledge/releateCommonInfo")
    public ModelAndView releateCommonInfo() {
        // Model model=new Model() ;
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeManage/releateCommonInfo");
        return mod;
    }

    @RequestMapping("/knowledge/getCommoninfoKnowledge")
    @ResponseBody
    public Result getCommoninfoKnowledge(String parentid, String catalogid, String title, String user, int draw, int start, int length) {
        //region 获取排序字段
//        String orderdata = GetOrderdata();
//        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        catalogid = helper.unescape(catalogid);
        if (catalogid == null || catalogid.equals("")) {
            catalogid = "00000000-0000-0000-0000-000000000000";
        }
        title = helper.unescape(title);
        user = helper.unescape(user);

        ArrayList<T_cms_knowledgeform> list = new ArrayList<T_cms_knowledgeform>();
        try {
            list = _commoninfoservice.findknowledge(catalogid, parentid, title, user, begin, end);
            int tot = _commoninfoservice.findknowledgecount(catalogid, parentid, title, user);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_cms_knowledgeform>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/knowledge/addcommoninfo")
    @ResponseBody
    public int addCommoninfo(String jsonstring) {
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            Type type = new TypeToken<ArrayList<String>>() {
            }.getType();
            ArrayList<String> codelist = gson.fromJson(jsonstring, type);
            _commoninfoservice.add(codelist, getCurrentUser().getUsercode());
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/knowledge/delcommoninfo")
    @ResponseBody
    public int delCommoninfo(String jsonstring) {
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            Type type = new TypeToken<ArrayList<String>>() {
            }.getType();
            ArrayList<String> codelist = gson.fromJson(jsonstring, type);
            _commoninfoservice.del(codelist);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/knowledge/isorder")
    @ResponseBody
    public int isorder(String id, int order) {
        int i = 1;
        try {
            return _channelService.isknowledgeorder(id, order);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/knowledge/updateorder")
    @ResponseBody
    public int updateorder(String id, int order) {
        int i = 1;
        try {
            channel entity = _channelService.findbyID(id);
            _channelService.updateknowledgeorder(id, order, (int) entity.getorderid());
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }
    @RequestMapping("/knowledge/del")
    @ResponseBody
    public ResultMsg delbyid(@RequestParam(value = "id") String id) {
        ResultMsg ret = new ResultMsg();
        String userid = getCurrentUser().getUserid();
        Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        try {
            if (id != null && !id.equals("")) {
                T_cms_knowledgeform item = _knowledgeformService.findByID(id);
                String beforeContent=gson.toJson(item);
                item.setisdelete(1);//0未删除 1已删除
                boolean result=_knowledgeformService.deleteList(id,getCurrentUser());
                if (result) {
                    ret.setState(1);
                    ret.setMsg("删除成功");
                    //插入操作日志
                    CmnFunction.InsertOperationLog(item.getSitecode(),OperationType.Update,FormType.T_CMS_KnowledgeForm,item.getId(),beforeContent,gson.toJson(item));
                } else {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            } else {
                ret.setState(0);
                ret.setMsg("没有要删除的行");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/knowledge/dellist")
    @ResponseBody
    public ResultMsg delListByIds(@RequestParam(value = "ids") String ids) {
        ResultMsg ret = new ResultMsg();
        T_employee user = getCurrentUser();
        try {
            if (ids != null && ids.length() > 0) {
                boolean result=_knowledgeformService.deleteList(ids,user);
                if (result) {
                    ret.setState(1);
                    ret.setMsg("删除成功");
                } else {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            } else {
                ret.setState(0);
                ret.setMsg("没有要删除的行");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("批量删除文章操作异常，操作人:" + user.getUsername() + "(" + user.getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }
}
