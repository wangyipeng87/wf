package com.autohome.cms.controller;

import com.autohome.cms.Entity.T_cms_hotwords;
import com.autohome.cms.Entity.T_cms_site;
import com.autohome.cms.Entity.T_employee;
import com.autohome.cms.service.HotWordsService;
import com.autohome.cms.service.SiteService;
import com.autohome.common.LoggerHelper;
import com.autohome.common.Result;
import com.autohome.common.ResultMsg;
import com.autohome.common.helper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/6/16.
 */
@Controller
public class hotwordsController extends baseController{

    @Resource
    SiteService _siteService;
    @Resource
    HotWordsService _wordService;

    @RequestMapping("/word/list")
    public ModelAndView listPage(){
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/HotWords/WordList");
        mod.addObject("username",emp.getUsername());
        return mod;
    }

    @RequestMapping("/word/add")
    public ModelAndView add(){
        String fromname="编辑";
        String id= helper.getParameter("id");
        if(id==null||id.equals(""))
        {
            id = java.util.UUID.randomUUID().toString();
            fromname="添加";
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/HotWords/AddWord");
        mod.addObject("username",emp.getUsername());
        mod.addObject("id",id);
        mod.addObject("fromname", fromname);
        return mod;
    }


    @RequestMapping("/word/GetAllList")
    @ResponseBody
    public Result GetList(String name, String code, String sitecode, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start==0?start:start+1;
        int end=start==0?start+length:start+length;
        Result res=new Result();
        name= helper.unescape(name);
        sitecode= helper.unescape(sitecode);
        code= helper.unescape(code);
        ArrayList<T_cms_hotwords> list = new ArrayList<T_cms_hotwords>();
        try {
            list=_wordService.findAllPager(name,code,sitecode,orderdata,orderdir,begin,end);
            if(list==null)
            {
                list = new ArrayList<T_cms_hotwords>();
            }
            int tot=_wordService.findAllCount(name,code,sitecode);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }


    @RequestMapping("/word/updatestate")
    @ResponseBody
    public ResultMsg updatestate(String id, int state) {
        ResultMsg ret=new ResultMsg();
        try {
            T_cms_hotwords entity =new T_cms_hotwords();
            entity.setId(id);
            entity.setState(new Long(state));
            entity.setModifiedby(getCurrentUser().getUserid());
            int result=_wordService.updateState(entity);
            if(result>0) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }


    @RequestMapping("/word/updateorder")
    @ResponseBody
    public ResultMsg updateorder(String id, int ordernum) {
        ResultMsg ret=new ResultMsg();
        try {
            T_cms_hotwords entity =new T_cms_hotwords();
            entity.setId(id);
            entity.setOrdernum(new Long(ordernum));
            entity.setModifiedby(getCurrentUser().getUserid());
            int result=_wordService.updateOrder(entity);
            if(result>0) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/word/del")
    @ResponseBody
    public ResultMsg delbyid(@RequestParam(value = "id") String id){
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {
            if(id!=null && !id.equals(""))
            {
                int result = _wordService.delete(id);
                if (result > 0) {
                    ret.setState(1);
                    ret.setMsg("删除成功");
                } else {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            }
            else
            {
                ret.setState(0);
                ret.setMsg("没有要删除的行");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/word/getbyid")
    @ResponseBody
    public T_cms_hotwords getbyid(@RequestParam(value = "id") String id){
        T_cms_hotwords entity= _wordService.findbyID(id);
        if(entity==null) {
            entity=new T_cms_hotwords();
            entity.setId(java.util.UUID.randomUUID().toString());
            entity.setState(new Long(1));
            entity.setOrdernum(new Long(1));
        }
        return entity;
    }

    @RequestMapping("/word/GetSiteOptions")
    @ResponseBody
    public ArrayList<T_cms_site> GetSiteOptions() {
        ArrayList<T_cms_site> list = new ArrayList<T_cms_site>();
        try {
            list=_siteService.findAllSite("","","","",0,Integer.MAX_VALUE);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/word/save")
    @ResponseBody
    public ResultMsg save(String id, String wordcode, String sitecode, String wordname,int ordernum, int state,  String remark) {
        ResultMsg ret=new ResultMsg();
        try {
            String userid=getCurrentUser().getUserid();
            T_cms_hotwords entity =_wordService.findbyID(id);
            if(entity==null)
            {
                T_cms_hotwords selective=new T_cms_hotwords();
                selective.setSitecode(helper.unescape(sitecode));
                selective.setWordname(helper.unescape(wordname));
                ArrayList<T_cms_hotwords> chklist=_wordService.findBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    ret.setState(0);
                    ret.setMsg("搜索热词已存在");
                    return ret;
                }
                entity=new T_cms_hotwords();
                entity.setId(java.util.UUID.randomUUID().toString());
                entity.setState(new Long(state));
                entity.setCreateby(userid);
                entity.setSitecode(helper.unescape(sitecode));
                entity.setWordcode(helper.unescape(wordcode));
                entity.setWordname(helper.unescape(wordname));
                entity.setOrdernum(new Long(ordernum));
                entity.setRemark(helper.unescape(remark));
                entity.setModifiedby(userid);
                int result=_wordService.insert(entity);
                if(result>0) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
            else
            {
                T_cms_hotwords selective=new T_cms_hotwords();
                selective.setWordname(helper.unescape(wordname));
                List<T_cms_hotwords> chklist=_wordService.findBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    long chkcount=chklist.stream().filter(chk -> !chk.getId().equals(id)).count();
                    if(chkcount>0) {
                        ret.setState(0);
                        ret.setMsg("搜索热词已存在");
                        return ret;
                    }
                }
                entity.setState(new Long(state));
                entity.setSitecode(helper.unescape(sitecode));
                entity.setWordcode(helper.unescape(wordcode));
                entity.setWordname(helper.unescape(wordname));
                entity.setOrdernum(new Long(ordernum));
                entity.setRemark(helper.unescape(remark));
                entity.setModifiedby(userid);
                int result=_wordService.update(entity);
                if(result>0) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存搜索热词异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }



}
