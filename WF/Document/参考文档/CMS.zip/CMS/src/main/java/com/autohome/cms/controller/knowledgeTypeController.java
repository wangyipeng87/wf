package com.autohome.cms.controller;

import com.autohome.cms.Entity.T_cms_knowledgedepart;
import com.autohome.cms.Entity.T_cms_knowledgeuser;
import com.autohome.cms.Entity.T_employee;
import com.autohome.cms.Entity.channel;
import com.autohome.cms.service.*;
import com.autohome.common.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Administrator on 2017/6/19.
 */
@Controller
public class knowledgeTypeController extends baseController {

    @Resource
    ChannelService _channelService;
    @Resource
    RoleService _roleService;
    @Resource
    KnowledgeformService _knowledgeformService;
    @Resource
    RoleUserService _roleUserService;
    @Resource
    DeptinfoService _deptinfoService;
    @Resource
    KnowledgedepartService _knowledgedepartService;
    @Resource
    KnowledgeuserService _knowledgeuserService;

    @RequestMapping("/knowledgetype/knowledgeTypeList")
    public ModelAndView showHomePage() {

        //   Model model=new Model() ;
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeTypeManage/knowledgeTypeList");
        return mod;
    }

    @RequestMapping("/knowledgetype/GetList")
    @ResponseBody
    public Result GetList(String parentcode, String name, String createuser, int state, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        name = helper.unescape(name);
        createuser = helper.unescape(createuser);
        ArrayList<channel> list = new ArrayList<channel>();
        try {
            list = _channelService.findchannel(parentcode, name, createuser, state, "knowledge", getCurrentUser().getUsercode(), "", orderdata, orderdir, begin, end);
            int tot = _channelService.findchannelCount(parentcode, name, createuser, state, "knowledge", getCurrentUser().getUsercode(), "");
            if (list == null && list.size() == 0) {
                list = new ArrayList<channel>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/knowledgetype/updatestate")
    @ResponseBody
    public int updatestate(String id, int state) {
        try {
            _channelService.UpdateState(id, state);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/knowledgetype/add")
    public ModelAndView add() {
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        T_employee emp = getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeTypeManage/knowledgeTypeAdd");
        mod.addObject("id", id);
        return mod;
    }

    @RequestMapping("/knowledgetype/getbyid")
    @ResponseBody
    public channel getbyid(@RequestParam(value = "id") String id) {
        channel entity = _channelService.findbyID(id);
        if (entity == null) {
            entity = new channel();
            entity.setid(java.util.UUID.randomUUID().toString());
            entity.setstate(1);
            entity.setorderid(_knowledgeformService.getmaxqi() + 1);
        }
        return entity;
    }

    @RequestMapping("/knowledgetype/save")
    @ResponseBody
    public int save(String id, String name, String style, String description, String channeltype, String parentcode, int ischild, int orderid, int state) {
        try {
            channel entity = new channel();
            entity = _channelService.findbyID(id);
            if (entity == null) {
                entity = new channel();
                entity.setid(java.util.UUID.randomUUID().toString());
                entity.setcreateuserid(getCurrentUser().getUserid());
            }
            entity.setname(helper.unescape(name));
            entity.setstyle(helper.unescape(style));
            entity.setdescription(helper.unescape(description));
            entity.setparentcode(helper.unescape(parentcode));
            entity.setischild(ischild);
            entity.setorderid(orderid);
            entity.setstate(state);
            entity.setsitecode(helper.unescape(""));
            entity.setupdateuserid(getCurrentUser().getUserid());
            entity.setchanneltype(helper.unescape(channeltype));
            _channelService.save(entity);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/knowledgetype/GetListForSelect")
    @ResponseBody
    public ArrayList<channel> GetListForSelect(@RequestParam(value = "ischild") int ischild, @RequestParam(value = "channeltype") String channeltype) {
        //String sitecode,
        channeltype = helper.unescape(channeltype);
        ArrayList<channel> list = new ArrayList<channel>();
        try {
            list = _channelService.findchannelforselect(getCurrentUser().getUsercode(), "", channeltype, ischild);

        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/knowledgetype/dept")
    public ModelAndView dept() {
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        T_employee emp = getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeTypeManage/KnowledgeTypeDeptList");
        mod.addObject("id", id);
        return mod;
    }


    @RequestMapping("/knowledgetype/getknowledgedepinfo")
    @ResponseBody
    public List<T_cms_knowledgedepart> getdepinfoall(String id) {
        List<T_cms_knowledgedepart> list = _knowledgedepartService.getDeptByFormid(id);
        return list;
    }

    @RequestMapping("/knowledgetype/getdepinfoall")
    @ResponseBody
    public List<EasyTreeNode> getdepinfoall() {
        List<EasyTreeNode> tree = new ArrayList<EasyTreeNode>();
        String rootCode = "00000001";
        EasyTreeNode root = _deptinfoService.GetEasyTreeByRootCode(rootCode);
        tree.add(root);
        return tree;
    }

    @RequestMapping("/knowledgetype/savedept")
    @ResponseBody
    public ResultMsg saveDept(String id, String deptids)
    {
        boolean result=true;
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {
            channel entity = _channelService.findbyID(id);
            _knowledgedepartService.delfile(id);
            if(deptids!=null && !deptids.equals(""))
            {
                List<String> addresult = Arrays.asList(deptids.split(","));
                for(String did:addresult)
                {
                    if(!did.equals(""))
                    {
                        T_cms_knowledgedepart deptentity = new T_cms_knowledgedepart();
                        deptentity.setid(java.util.UUID.randomUUID().toString());
                        deptentity.setdepartcode(did);
                        deptentity.setcreatedby(userid);
                        deptentity.setsitecode(entity.getsitecode());
                        deptentity.setknowledgeformid(id);
                        deptentity.setmodifiedby(userid);
                        _knowledgedepartService.adddeptinfo(deptentity);
                    }
                }
            }
            ret.setState(1);
            ret.setMsg("保存成功");
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存知识库类型的部门异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }





    @RequestMapping("/knowledgetype/user")
    public ModelAndView user() {
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        T_employee emp = getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeTypeManage/KnowledgeTypeUserList");
        mod.addObject("id", id);
        return mod;
    }

    @RequestMapping("/knowledgetype/adduser")
    public ModelAndView adduser() {
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        channel entity = _channelService.findbyID(id);
        T_employee emp = getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/knowledgeTypeManage/AddKnowledgeTypeUser");
        mod.addObject("id", id);
        mod.addObject("channel",entity);
        return mod;
    }

//    @RequestMapping("/knowledgetype/GetAllUserListByKnowledgeFormId")
//    @ResponseBody
//    public Result GetUserListByKnowledgeFormId(String name, String code,String knowledgeformid, int ischecked,  int draw, int start, int length) {
//        //region 获取排序字段
//        String orderdata = GetOrderdata();
//        String orderdir = GetOrderdir();
//        //endregion
//        int begin=start==0?start:start+1;
//        int end=start==0?start+length:start+length;
//        Result res=new Result();
//        name= helper.unescape(name);
//        code= helper.unescape(code);
//        knowledgeformid=helper.unescape(knowledgeformid);
//        ArrayList<T_cms_knowledgeuser> list = new ArrayList<T_cms_knowledgeuser>();
//        try {
//            list=_knowledgeuserService.findAllEmpPagerByKnowledgeFormId(name,code,knowledgeformid,ischecked,orderdata,orderdir,begin,end);
//            int tot=_knowledgeuserService.findAllEmpCountByKnowledgeFormId(name,code,knowledgeformid,ischecked);
//            res.setdata(list);
//            res.setdraw(draw);
//            res.setrecordsFiltered(tot);
//            res.setrecordsTotal(tot);
//        } catch (Exception ex) {
//            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
//        }
//        return res;
//    }

    @RequestMapping("/knowledgetype/GetAllUserList")
    @ResponseBody
    public Result GetUserList(String name, String code,String knowledgeformid,  int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start==0?start:start+1;
        int end=start==0?start+length:start+length;
        Result res=new Result();
        name= helper.unescape(name);
        code= helper.unescape(code);
        knowledgeformid=helper.unescape(knowledgeformid);
        ArrayList<T_cms_knowledgeuser> list = new ArrayList<T_cms_knowledgeuser>();
        try {
            list=_knowledgeuserService.findAllPager(name,code,knowledgeformid,orderdata,orderdir,begin,end);
            int tot=_knowledgeuserService.findAllCount(name,code,knowledgeformid);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

//    @RequestMapping("/knowledgetype/saveuser")
//    @ResponseBody
//    public ResultMsg saveUser(String id,String addusers,String delusers)
//    {
//        boolean result=true;
//        ResultMsg ret=new ResultMsg();
//        String userid=getCurrentUser().getUserid();
//        try {
//            if(delusers!=null && !delusers.equals(""))
//            {
//                List<String> delresult = Arrays.asList(delusers.split(","));
//                for(String uid:delresult)
//                {
//                    if(!uid.equals(""))
//                    {
//                        _knowledgeuserService.delete(uid,id);
//                    }
//                }
//            }
//            if(addusers!=null && !addusers.equals(""))
//            {
//                channel entity = _channelService.findbyID(id);
//                List<String> addresult = Arrays.asList(addusers.split(","));
//                for(String uid:addresult)
//                {
//                    if(!uid.equals(""))
//                    {
//                        T_cms_knowledgeuser userentity = new T_cms_knowledgeuser();
//                        userentity.setid(java.util.UUID.randomUUID().toString());
//                        userentity.setuserid(uid);
//                        userentity.setcreatedby(userid);
//                        userentity.setsitecode(entity.getsitecode());
//                        userentity.setknowledgeformid(id);
//                        userentity.setmodifiedby(userid);
//                        _knowledgeuserService.addUser(userentity);
//                    }
//                }
//            }
//            ret.setState(1);
//            ret.setMsg("保存成功");
//        } catch (Exception ex) {
//            ret.setState(0);
//            ret.setMsg("保存失败");
//            LoggerHelper.error("保存知识库类型的人员异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
//        }
//        return ret;
//    }

    @RequestMapping("/knowledgetype/getEmpListByKnowledgeFormId")
    @ResponseBody
    public ArrayList<T_cms_knowledgeuser> getemplist(String user,String knowledgeformid) {
        ArrayList<T_cms_knowledgeuser> list = new ArrayList<T_cms_knowledgeuser>();
        user = helper.unescape(user);
        knowledgeformid=helper.unescape(knowledgeformid);
        try {
            list = _knowledgeuserService.findEmpByKnowledgeFormId(user,knowledgeformid);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/knowledgetype/saveuser")
    @ResponseBody
    public ResultMsg saveUser(String id,String uid)
    {
        boolean result=true;
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {

            if(id!=null && !id.trim().equals("") && uid!=null && !uid.trim().equals("")) {
                T_cms_knowledgeuser userentity = new T_cms_knowledgeuser();
                userentity.setknowledgeformid(id);
                userentity.setuserid(uid);
                ArrayList<T_cms_knowledgeuser> chklist=  _knowledgeuserService.findBySelective(userentity);
                if(chklist!=null && chklist.size()>0)
                {
                    ret.setState(0);
                    ret.setMsg("人员已存在");
                    return ret;
                }

                channel entity = _channelService.findbyID(id);
                userentity.setsitecode(entity.getsitecode());
                userentity.setid(java.util.UUID.randomUUID().toString());
                userentity.setcreatedby(userid);
                userentity.setmodifiedby(userid);
                _knowledgeuserService.addUser(userentity);

                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败，参数错误。");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存知识库的人员异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }


    @RequestMapping("/knowledgetype/deluser")
    @ResponseBody
    public ResultMsg delUser(String id,String uid)
    {
        boolean result=true;
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {

            if(id!=null && !id.trim().equals("") && uid!=null && !uid.trim().equals("")) {

                _knowledgeuserService.delete(uid,id);

                ret.setState(1);
                ret.setMsg("删除成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("删除失败，参数错误。");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("删除知识库的人员异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }





}
