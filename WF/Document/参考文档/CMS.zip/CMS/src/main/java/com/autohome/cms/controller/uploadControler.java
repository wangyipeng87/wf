package com.autohome.cms.controller;


import com.autohome.cms.Entity.T_cms_contentfile;
import com.autohome.cms.service.ContentFileService;
import com.autohome.cms.service.ContentService;
import com.autohome.common.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;


/**
 * Created by Administrator on 2017/5/22.
 */
@Controller
public class uploadControler extends baseController {


    @Value("#{configProperties['UpImgPath']}")
    private String UpImgPath;

    @Value("#{configProperties['AccessImgUrl']}")
    private String AccessImgUrl;

    @Value("#{configProperties['UpTmpPath']}")
    private String UpTmpPath;

    @Value("#{configProperties['AccessTmpUrl']}")
    private String AccessTmpUrl;

    @Value("#{configProperties['FtpServerUrl']}")
    private String FtpServerUrl;

    @Value("#{configProperties['FtpUserName']}")
    private String FtpUserName;

    @Value("#{configProperties['FtpPassword']}")
    private String FtpPassword;

    @Value("#{configProperties['FtpFilePath']}")
    private String FtpFilePath;

    @Value("#{configProperties['SimplePicUrl']}")
    private String SimplePicUrl;
    @Value("#{configProperties['AccessSimplePicUrl']}")
    private String AccessSimplePicUrl;
    @Value("#{configProperties['ZipDir']}")
    private String ZipDir;

    @Resource
    ContentFileService _contentFileService;
    @Resource
    ContentService _contentService;

    @RequestMapping("/uploadfile/ftp")
    @ResponseBody
    public UploadFileResult uploadFtp(@RequestParam(value = "Filedata") MultipartFile file, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        UploadFileResult fileResult = new UploadFileResult();
        try {
            if (file != null && !file.isEmpty()) {
                String strOFileName = file.getOriginalFilename();
                String strFileSuffix = strOFileName.substring(strOFileName.lastIndexOf("."));
                String nameex = java.util.UUID.randomUUID().toString();
                String strFileName = nameex + strFileSuffix;
                fileResult.setOFileName(strOFileName);
                fileResult.setFileName(strFileName);
                fileResult.setFileSize(file.getSize());
                fileResult.setfilenameex(nameex);
                fileResult.setfilesuffix(strFileSuffix);
                fileResult.setFilePath(FtpFilePath.trim() + (FtpFilePath.trim().endsWith("/") ? "" : "/"));
                boolean success = FtpHelper.uploadFile(FtpServerUrl, 21, FtpUserName.trim(), FtpPassword.trim(), FtpFilePath.trim(), strFileName, file.getInputStream());
                if (success) {
                    fileResult.setState(1);
                }
            } else {
                fileResult.setState(0);
                fileResult.setCode("没有要上传的文件");
            }
        } catch (Exception ex) {
            fileResult.setState(0);
            fileResult.setCode(ex.getMessage());
            LoggerHelper.error("FTP上传异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return fileResult;
    }

    @RequestMapping("/uploadfile/ftpdownfile")
    @ResponseBody
    public UploadFileResult ftpdownfile(String filename, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        UploadFileResult fileResult = new UploadFileResult();
        try {
            if (filename != null && !filename.isEmpty()) {
                String strPath = session.getServletContext().getRealPath(UpImgPath.trim() + (UpImgPath.trim().endsWith("/") ? "" : "/") + "tmp/");
                File dir = new File(strPath);
                if (!dir.exists()) {
                    dir.mkdir();
                }
                boolean success = FtpHelper.downFile(FtpServerUrl.trim(), 21, FtpUserName.trim(), FtpPassword.trim(), FtpFilePath.trim(), filename, strPath);
                if (success) {
                    //读取文件
                    File file = new File(strPath + filename);
                    if (file.exists()) {
                        String oldname = filename;
                        try {
                            oldname = _contentFileService.findFileNameByFtpName(filename.substring(0, filename.lastIndexOf(".")));
                        } catch (Exception ex) {
                            oldname = filename;
                        }
                        if (oldname == null) {
                            oldname = filename;
                        }
                        if (helper.getBrowser().toLowerCase().contains("ie") || helper.getBrowser().toLowerCase().contains("trident")) {
                            oldname = java.net.URLEncoder.encode(oldname, "UTF-8");
                        } else {
                            oldname = new String(oldname.getBytes("UTF-8"), "ISO-8859-1");
                        }

                        FileInputStream is;
                        is = new FileInputStream(file);
                        ServletOutputStream os = response.getOutputStream();
                        BufferedOutputStream bos = new BufferedOutputStream(os);
                        response.setHeader("Content-Disposition", "attachment; filename=\"" + oldname + "\"");
                        byte[] len = new byte[1024 * 2];
                        int read = 0;
                        while ((read = is.read(len)) != -1) {
                            bos.write(len, 0, read);
                        }
                        bos.flush();
                        bos.close();
                        is.close();
                        file.deleteOnExit();
                        fileResult.setState(1);
                    } else {
                        fileResult.setState(0);
                        fileResult.setCode("FTP下载文件失败");
                    }
                } else {
                    fileResult.setState(0);
                    fileResult.setCode("FTP下载文件失败");
                }
            } else {
                fileResult.setState(0);
                fileResult.setCode("请指定要下载的文件");
            }
        } catch (Exception ex) {
            fileResult.setState(0);
            fileResult.setCode(ex.getMessage());
            LoggerHelper.error("FTP下载异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return fileResult;
    }

    @RequestMapping("/uploadfile/downfilebyContentid")
    @ResponseBody
    public UploadFileResult downfilebyContentid(String contentid, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        UploadFileResult fileResult = new UploadFileResult();
        try {
            File ziproot = new File(session.getServletContext().getRealPath(ZipDir.trim() + (ZipDir.trim().endsWith("/") ? "" : "/")));
            CCRDFile.deleteFolder(ziproot);
            if (contentid != null && !contentid.isEmpty()) {
                String dir = java.util.UUID.randomUUID().toString();
                String strPath = session.getServletContext().getRealPath(ZipDir.trim() + (ZipDir.trim().endsWith("/") ? "" : "/") + dir);
                CCRDFile.createDir(strPath);
                ArrayList<T_cms_contentfile> filelist = _contentFileService.findByContentCode(contentid);
                if (filelist != null && filelist.size() > 0) {
                    for (int i = 0; i < filelist.size(); i++) {
                        boolean success = FtpHelper.downFile(FtpServerUrl.trim(), 21, FtpUserName.trim(), FtpPassword.trim(), FtpFilePath.trim(), filelist.get(i).getFilenameex() + filelist.get(i).getFilesuffix(), strPath,filelist.get(i).getFilename() );
                    }
                }
                String zipPath = session.getServletContext().getRealPath(ZipDir.trim() + (ZipDir.trim().endsWith("/") ? "" : "/") + dir + ".zip");
                ZipCompress zipCom = new ZipCompress(zipPath, strPath);
                zipCom.zip();
                //读取文件
                File file = new File(zipPath);
                if (file.exists()) {
                    String oldname = "";
                    try {
                        oldname = _contentService.findByID(contentid).getcontenttitle() + ".zip";
                    } catch (Exception ex) {
                        oldname = dir + ".zip";
                    }
                    if (oldname == null) {
                        oldname = dir + ".zip";
                    }
                    if (helper.getBrowser().toLowerCase().contains("ie") || helper.getBrowser().toLowerCase().contains("trident")) {
                        oldname = java.net.URLEncoder.encode(oldname, "UTF-8");
                    } else {
                        oldname = new String(oldname.getBytes("UTF-8"), "ISO-8859-1");
                    }

                    FileInputStream is;
                    is = new FileInputStream(file);
                    ServletOutputStream os = response.getOutputStream();
                    BufferedOutputStream bos = new BufferedOutputStream(os);
                    response.setHeader("Content-Disposition", "attachment; filename=\"" + oldname + "\"");
                    byte[] len = new byte[1024 * 2];
                    int read = 0;
                    while ((read = is.read(len)) != -1) {
                        bos.write(len, 0, read);
                    }
                    bos.flush();
                    bos.close();
                    is.close();
                    file.deleteOnExit();
                    fileResult.setState(1);
                } else {
                    fileResult.setState(0);
                    fileResult.setCode("FTP下载文件失败");
                }
            } else {
                fileResult.setState(0);
                fileResult.setCode("请指定要下载的文件");
            }
        } catch (Exception ex) {
            fileResult.setState(0);
            fileResult.setCode(ex.getMessage());
            LoggerHelper.error("FTP下载异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return fileResult;
    }

    @RequestMapping("/uploadfile/image")
    @ResponseBody
    public UploadFileResult uploadImage(@RequestParam(value = "Filedata") MultipartFile file, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        UploadFileResult fileResult = new UploadFileResult();
        try {
            if (file != null && !file.isEmpty()) {
                if (file.getContentType().startsWith("image")) {
                    String strOFileName = file.getOriginalFilename();
                    String strFileSuffix = strOFileName.substring(strOFileName.lastIndexOf("."));
                    String strFileName = java.util.UUID.randomUUID() + strFileSuffix;
                    fileResult.setOFileName(strOFileName);
                    fileResult.setFileName(strFileName);
                    fileResult.setFileSize(file.getSize());
                    fileResult.setFilePath(AccessImgUrl.trim() + (AccessImgUrl.trim().endsWith("/") ? "" : "/"));
                    File localFile = new File(session.getServletContext().getRealPath(UpImgPath.trim() + (UpImgPath.trim().endsWith("/") ? "" : "/")) + strFileName);
                    if (!localFile.getParentFile().exists()) {
                        localFile.getParentFile().mkdir();
                    }
                    file.transferTo(localFile);
                    fileResult.setState(1);
                } else {
                    fileResult.setState(0);
                    fileResult.setCode("上传的不是图片");
                }
            } else {
                fileResult.setState(0);
                fileResult.setCode("没有要上传的图片");
            }
        } catch (Exception ex) {
            fileResult.setState(0);
            fileResult.setCode(ex.getMessage());
            LoggerHelper.error("上传图片异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return fileResult;
    }

    @RequestMapping("/uploadfile/SimplePicUrl")
    @ResponseBody
    public UploadFileResult uploadSimplePicUrl(@RequestParam(value = "Filedata") MultipartFile file, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        UploadFileResult fileResult = new UploadFileResult();
        try {
            if (file != null && !file.isEmpty()) {
                if (file.getContentType().startsWith("image")) {
                    String strOFileName = file.getOriginalFilename();
                    String strFileSuffix = strOFileName.substring(strOFileName.lastIndexOf("."));
                    String strFileName = java.util.UUID.randomUUID() + strFileSuffix;
                    fileResult.setOFileName(strOFileName);
                    fileResult.setFileName(strFileName);
                    fileResult.setFileSize(file.getSize());
                    fileResult.setFilePath(AccessSimplePicUrl.trim() + (AccessSimplePicUrl.trim().endsWith("/") ? "" : "/"));
                    File localFile = new File(session.getServletContext().getRealPath(SimplePicUrl.trim() + (SimplePicUrl.trim().endsWith("/") ? "" : "/")) + strFileName);
                    if (!localFile.getParentFile().exists()) {
                        localFile.getParentFile().mkdir();
                    }
                    file.transferTo(localFile);
                    fileResult.setState(1);
                } else {
                    fileResult.setState(0);
                    fileResult.setCode("上传的不是图片");
                }
            } else {
                fileResult.setState(0);
                fileResult.setCode("没有要上传的图片");
            }
        } catch (Exception ex) {
            fileResult.setState(0);
            fileResult.setCode(ex.getMessage());
            LoggerHelper.error("上传图片异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return fileResult;
    }

    @RequestMapping("/uploadfile/tmp")
    @ResponseBody
    public UploadFileResult uploadTmp(@RequestParam(value = "Filedata") MultipartFile file, String folder, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        UploadFileResult fileResult = new UploadFileResult();
        try {
            if (file != null && !file.isEmpty()) {
                if (file.getOriginalFilename().toLowerCase().endsWith(".zip") ||
                        file.getOriginalFilename().toLowerCase().endsWith(".rar") ||
                        file.getOriginalFilename().toLowerCase().endsWith(".html") ||
                        file.getOriginalFilename().toLowerCase().endsWith(".htm") ||
//                        file.getOriginalFilename().toLowerCase().endsWith(".css")||
//                        file.getOriginalFilename().toLowerCase().endsWith(".js")||
                        file.getOriginalFilename().toLowerCase().endsWith(".jsp")) {
                    String strOFileName = file.getOriginalFilename();
                    String strFileSuffix = strOFileName.substring(strOFileName.lastIndexOf("."));
                    String strFileName = strOFileName;//java.util.UUID.randomUUID()+strFileSuffix;
                    fileResult.setOFileName(strOFileName);
                    fileResult.setFileName(strFileName);
                    fileResult.setFileSize(file.getSize());
                    fileResult.setFilePath(AccessTmpUrl.trim() + (AccessTmpUrl.trim().endsWith("/") ? "" : "/") + folder.trim() + "/");
                    String strPath = session.getServletContext().getRealPath(UpTmpPath.trim() + (UpTmpPath.trim().endsWith("/") ? "" : "/") + folder.trim() + "/") + strFileName;
                    File localFile = new File(strPath);
                    if (!localFile.getParentFile().exists()) {
                        localFile.getParentFile().mkdir();
                    }
                    file.transferTo(localFile);

                    boolean result = false;
                    if (file.getOriginalFilename().toLowerCase().endsWith(".zip")) {
                        result = ZipRarHelper.zipdecompression(localFile, session.getServletContext().getRealPath(UpTmpPath.trim() + (UpTmpPath.trim().endsWith("/") ? "" : "/") + folder.trim() + "/"));
                    } else if (file.getOriginalFilename().toLowerCase().endsWith(".rar")) {
                        result = ZipRarHelper.rardecompression(localFile, session.getServletContext().getRealPath(UpTmpPath.trim() + (UpTmpPath.trim().endsWith("/") ? "" : "/") + folder.trim() + "/"));
                    } else {
                        result = true;
                    }

                    if (result) {
                        fileResult.setState(1);
                    } else {
                        fileResult.setState(0);
                        fileResult.setCode("解压压缩包失败");
                    }
                } else {
                    fileResult.setState(0);
                    fileResult.setCode("上传的不是压缩包和html相关文件");
                }
            } else {
                fileResult.setState(0);
                fileResult.setCode("没有要上传的压缩包和html相关文件");
            }
        } catch (Exception ex) {
            fileResult.setState(0);
            fileResult.setCode(ex.getMessage());
            LoggerHelper.error("上传模板异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return fileResult;
    }

    @RequestMapping("/uploadfile/ziptmp")
    @ResponseBody
    public UploadFileResult ziptmpfile(String folder, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        UploadFileResult fileResult = new UploadFileResult();
        try {
            if (folder != null && !folder.isEmpty()) {
                String strPath = session.getServletContext().getRealPath(UpTmpPath.trim() + (UpTmpPath.trim().endsWith("/") ? "" : "/") + folder + "/");
                boolean result = ZipRarHelper.zidcompress(strPath, folder + ".zip", new String[]{"*.zip", "*.rar"});
                if (result) {
                    fileResult.setState(1);
                    fileResult.setCode("压缩完成，压缩文件：" + folder + ".zip");
                } else {
                    fileResult.setState(0);
                    fileResult.setCode("压缩模板失败");
                }
            } else {
                fileResult.setState(0);
                fileResult.setCode("请指定要压缩的模板");
            }
        } catch (Exception ex) {
            fileResult.setState(0);
            fileResult.setCode(ex.getMessage());
            LoggerHelper.error("压缩模板异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return fileResult;
    }

}
