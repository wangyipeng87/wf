package com.autohome.cms.controller;

import com.autohome.cms.Entity.*;
import com.autohome.cms.service.*;
import com.autohome.common.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.apache.commons.lang3.StringEscapeUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Administrator on 2017/5/31.
 */
@Controller
public class navlinkController extends baseController {

    @Resource
    SiteService _siteService;
    @Resource
    ModelService _modelService;
    @Resource
    NavLinkService _linkService;
    @Resource
    NavLinkRoleService _linkRoleService;
    @Resource
    SysRoleService _roleService;

    @RequestMapping("/link/list")
    public ModelAndView listPage(){
        String modelname="链接管理";
        String modelcode=helper.getParameter("modelcode");
        if(modelcode==null || modelcode.equals(""))
        {
            modelcode="M999";
        }
        T_cms_model selective=new T_cms_model();
        selective.setModelcode(modelcode);
        ArrayList<T_cms_model>  list=_modelService.findBySelective(selective);
        if(list!=null && list.size()>0)
        {
            modelname=list.get(0).getModelname();
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/NavLinkManage/LinkList");
        mod.addObject("username",emp.getUsername());
        mod.addObject("modelcode",modelcode);
        mod.addObject("modelname",modelname);
        return mod;
    }

    @RequestMapping("/link/add")
    public ModelAndView add(){
        String fromname="编辑";
        String id=helper.getParameter("id");
        String sitecode="";
        String modelname="链接管理";
        String modelcode=helper.getParameter("modelcode");
        String parentid=helper.getParameter("parentid");
        if(id==null||id.equals(""))
        {
            id = java.util.UUID.randomUUID().toString();
            fromname="添加";
            if(parentid!=null && !parentid.equals(""))
            {
                T_cms_navlink entity =_linkService.findLinkbyID(parentid);
                if(entity!=null)
                {
                    modelcode=entity.getModelcode();
                }
            }
        }
        else
        {
            T_cms_navlink entity= _linkService.findLinkbyID(id);
            if(entity!=null) {
                modelcode=entity.getModelcode();
                parentid=entity.getParentid();
            }
        }
        if(modelcode!=null && !modelcode.equals(""))
        {
            T_cms_model selective=new T_cms_model();
            selective.setModelcode(modelcode);
            ArrayList<T_cms_model>  list=_modelService.findBySelective(selective);
            if(list!=null && list.size()>0)
            {
                sitecode=list.get(0).getSitecode();
                modelname=list.get(0).getModelname();
            }
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/NavLinkManage/AddLink");
        mod.addObject("username",emp.getUsername());
        mod.addObject("id",id);
        mod.addObject("parentid",parentid);
        mod.addObject("sitecode",sitecode);
        mod.addObject("modelcode",modelcode);
        mod.addObject("modelname",modelname);
        mod.addObject("fromname", fromname);
        return mod;
    }


    @RequestMapping("/link/GetAllList")
    @ResponseBody
    public Result GetList(String name,String sitecode,String modelcode, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start==0?start:start+1;
        int end=start==0?start+length:start+length;
        Result res=new Result();
        name= helper.unescape(name);
        sitecode= helper.unescape(sitecode);
        modelcode= helper.unescape(modelcode);
        ArrayList<T_cms_navlink> list = new ArrayList<T_cms_navlink>();
        try {
            list=_linkService.findAllLinkPager(name,sitecode,modelcode,orderdata,orderdir,begin,end);
            if(list==null)
            {
                list = new ArrayList<T_cms_navlink>();
            }
            int tot=_linkService.findAllLinkCount(name,sitecode,modelcode);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }


    @RequestMapping("/link/GetAllTreeList")
    @ResponseBody
    public Result GetTreeList(String name,String sitecode,String modelcode, int draw, int start, int length)
    {
        Result res=new Result();
        name= helper.unescape(name);
        sitecode= helper.unescape(sitecode);
        modelcode= helper.unescape(modelcode);
        List<T_cms_navlink> list = new ArrayList<T_cms_navlink>();
        int tot=0;
        try {
            list=_linkService.findAllLinkPager(name,sitecode,modelcode,"","",0,Integer.MAX_VALUE);
            if(list!=null && list.size()>0) {
                Collections.sort(list);
                list = RecursiveLinkTreeNode(list, list.stream().filter(l -> l.getParentid().equals("00000000-0000-0000-0000-000000000000")).collect(Collectors.toList()),1);
                tot = list.size();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }



    @RequestMapping("/link/updatestate")
    @ResponseBody
    public ResultMsg updatestate(String id, int state,int field) {
        ResultMsg ret=new ResultMsg();
        try {
            T_cms_navlink entity =new T_cms_navlink();
            entity.setId(id);
            entity.setState(new Long(state));
            entity.setDisplaystate(new Long(state));
            entity.setModifiedby(getCurrentUser().getUserid());
            int result=0;
            if(field==0) {
                result = _linkService.updateState(entity);
            }
            else {
                result=_linkService.updateDisplay(entity);
            }
            if(result>0) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/link/updateorder")
    @ResponseBody
    public ResultMsg updateorder(String id, int ordernum) {
        ResultMsg ret=new ResultMsg();
        try {
            T_cms_navlink entity =new T_cms_navlink();
            entity.setId(id);
            entity.setOrdernum(new Long(ordernum));
            entity.setModifiedby(getCurrentUser().getUserid());
            int result=_linkService.updateOrder(entity);
            if(result>0) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }


    @RequestMapping("/link/updateorderbybatch")
    @ResponseBody
    public ResultMsg updateorderbybatch(String orderjson) {
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {
            if(orderjson!=null && !orderjson.equals("")) {
                Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
                Type type = new TypeToken<ArrayList<T_cms_navlink>>() {}.getType();
                List<T_cms_navlink> list=gson.fromJson(helper.unescape(orderjson), type);
                if(list!=null && list.size()>0) {
                    for (T_cms_navlink e : list) {
                        e.setModifiedby(userid);
                    }
                    int result = _linkService.updateOrderByBatch(list);
                    if (result > 0) {
                        ret.setState(1);
                        ret.setMsg("保存成功");
                    } else {
                        ret.setState(0);
                        ret.setMsg("保存失败");
                    }
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("没有要更新的行");
                }
            }
            else
            {
                ret.setState(0);
                ret.setMsg("没有要更新的行");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }


    @RequestMapping("/link/del")
    @ResponseBody
    public ResultMsg delbyid(@RequestParam(value = "id") String id){
        ResultMsg ret=new ResultMsg();
        String userid=getCurrentUser().getUserid();
        try {
            if(id!=null && !id.equals(""))
            {
                T_cms_navlink selective=new T_cms_navlink();
                selective.setParentid(id);
                ArrayList<T_cms_navlink> chklist=_linkService.findLinkBySelective(selective);
                if(chklist!=null && chklist.size()>0) {
                    ret.setState(0);
                    ret.setMsg("删除失败,当前项包含子级");
                    return  ret;
                }
                int result = _linkService.delete(id);
                if (result > 0) {
                    ret.setState(1);
                    ret.setMsg("删除成功");
                } else {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            }
            else
            {
                ret.setState(0);
                ret.setMsg("没有要删除的行");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }


    @RequestMapping("/link/getbyid")
    @ResponseBody
    public T_cms_navlink getbyid(@RequestParam(value = "id") String id){
        T_cms_navlink entity= _linkService.findLinkbyID(id);
        if(entity==null) {
            entity=new T_cms_navlink();
            entity.setId(java.util.UUID.randomUUID().toString());
            entity.setState(new Long(1));
            entity.setDisplaystate(new Long(1));
            entity.setLinktarget("");
            entity.setOrdernum(new Long(1));
        }
        T_cms_navlinkrole selective = new T_cms_navlinkrole();
        selective.setNavlinkid(helper.unescape(id));
        List<T_cms_navlinkrole>  list = _linkRoleService.findBySelective(selective);
        if(list!=null && list.size()>0)
        {
            StringBuilder result=new StringBuilder();
            boolean flag=false;
            for (T_cms_navlinkrole e : list) {
                if (flag) {
                    result.append(",");
                }else {
                    flag=true;
                }
                result.append(e.getRolecode());
            }
            entity.setRoles(result.toString());
        }
        return entity;
    }


    @RequestMapping("/link/GetSiteOptions")
    @ResponseBody
    public ArrayList<T_cms_site> GetSiteOptions() {
        ArrayList<T_cms_site> list = new ArrayList<T_cms_site>();
        try {
            list=_siteService.findAllSite("","","","",0,Integer.MAX_VALUE);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/link/GetModelOptions")
    @ResponseBody
    public ArrayList<T_cms_model> GetModelOptions(@RequestParam(value = "sitecode") String sitecode) {
        ArrayList<T_cms_model> list = new ArrayList<T_cms_model>();
        try {
            T_cms_model selective=new T_cms_model();
            selective.setState(new Long(1));
            selective.setSitecode(helper.unescape(sitecode));
            list=_modelService.findBySelective(selective);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }


    @RequestMapping("/link/GetLinkTreeOptions")
    @ResponseBody
    public List<T_cms_navlink> GetLinkTreeOptions(@RequestParam(value = "sitecode") String sitecode,@RequestParam(value = "modelcode") String modelcode) {
        List<T_cms_navlink> list = new ArrayList<T_cms_navlink>();
        try {
            T_cms_navlink selective=new T_cms_navlink();
            selective.setSitecode(helper.unescape(sitecode));
            selective.setModelcode(helper.unescape(modelcode));
            list=_linkService.findLinkBySelective(selective);
            if(list!=null && list.size()>0)
            {
                Collections.sort(list);
                list=RecursiveLinkTreeNode(list,list.stream().filter(l->l.getParentid().equals("00000000-0000-0000-0000-000000000000")).collect(Collectors.toList()),1);
            }
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    public List<T_cms_navlink> RecursiveLinkTreeNode(List<T_cms_navlink> alllist,List<T_cms_navlink> list,int index)
    {
        List<T_cms_navlink> nodelist=new ArrayList<T_cms_navlink>();
        if(list!=null && list.size()>0) {
            for (T_cms_navlink e : list) {
                if (e.getLevelnum() > 1) {
                    StringBuilder strSpace = new StringBuilder();
                    for (int i = 1; i < e.getLevelnum(); i++) {
                        strSpace.append("　");
                    }
                    strSpace.append("├");
                    e.setTitle(strSpace.toString() + StringEscapeUtils.escapeHtml4(e.getTitle()));
                }
                e.setIndex(index++);
                nodelist.add(e);
                List<T_cms_navlink> childnodelist = RecursiveLinkTreeNode(alllist, alllist.stream().filter(l -> l.getParentid().equals(e.getId())).collect(Collectors.toList()),index);
                if (childnodelist != null && childnodelist.size() > 0) {
                    nodelist.addAll(childnodelist);
                    index += childnodelist.size();
                }
            }
        }
        return nodelist;
    }


    @RequestMapping("/link/savelink")
    @ResponseBody
    public ResultMsg savelink(String id, String parentid, String sitecode,String modelcode, String title,int state,String linkurl,String iconurl,int displaytype,int displaystate,String remark,int ordernum,String css,String roles,String linktarget,String subtitle,String html) {
        ResultMsg ret=new ResultMsg();
        boolean result=true;
        try {
            String userid=getCurrentUser().getUserid();
            T_cms_navlink entity =_linkService.findLinkbyID(id);
            if(entity==null)
            {
                entity=new T_cms_navlink();
                entity.setId(java.util.UUID.randomUUID().toString());
                entity.setState(new Long(state));
                entity.setCreateby(userid);
                entity.setParentid(parentid);
                T_cms_navlink parentity =_linkService.findLinkbyID(parentid);
                if(parentity!=null) {
                    entity.setLevelnum(parentity.getLevelnum() + 1);
                }
                else {
                    entity.setLevelnum(new Long(1));
                }
                entity.setSitecode(helper.unescape(sitecode));
                entity.setModelcode(helper.unescape(modelcode));
                entity.setTitle(helper.unescape(title));
                entity.setLinkurl(helper.unescape(linkurl));
                entity.setIconurl(helper.unescape(iconurl));
                entity.setDisplaystate(new Long(displaystate));
                entity.setDisplaytype(new Long(displaytype));
                entity.setOrdernum(new Long(ordernum));
                entity.setCss(helper.unescape(css));
                entity.setRemark(helper.unescape(remark));
                entity.setModifiedby(userid);
                entity.setSubtitle(helper.unescape(subtitle));
                entity.setLinktarget(helper.unescape(linktarget));
                entity.setHtml(helper.unescape(html));
                result=_linkService.insert(entity)>0;

                T_cms_navlinkrole upentity=new T_cms_navlinkrole();
                upentity.setNavlinkid(entity.getId());
                upentity.setState(new Long(0));
                upentity.setModifiedby(userid);
                _linkRoleService.updateStateBySelective(upentity);
                if(roles!=null && !roles.equals(""))
                {
                    List<String> addresult = Arrays.asList(roles.split(","));
                    List<T_cms_navlinkrole> addlist=new ArrayList<T_cms_navlinkrole>();
                    for(String rc:addresult)
                    {
                        if(rc!=null && !rc.equals("")) {
                            T_cms_navlinkrole rcentity = new T_cms_navlinkrole();
                            rcentity.setId(java.util.UUID.randomUUID().toString());
                            rcentity.setRolecode(rc);
                            rcentity.setNavlinkid(entity.getId());
                            rcentity.setState(new Long(1));
                            rcentity.setCreateby(userid);
                            rcentity.setModifiedby(userid);
                            addlist.add(rcentity);
                        }
                    }
                    if(addlist.size()>0) {
                        int size=100;
                        if(addlist.size()<=size) {
                            result &= _linkRoleService.insertByBatch(addlist) > 0;
                        }
                        else
                        {
                            int page=addlist.size()%size==0?addlist.size()/size:(addlist.size()/size)+1;
                            int begin=0;
                            int end=size;
                            for(int i=0;i<page;i++)
                            {
                                result &= _linkRoleService.insertByBatch(addlist.subList(begin,(end>addlist.size()?addlist.size():end))) > 0;
                                begin += size;
                                end = begin + size;
                            }
                        }
                    }
                }
                if(result) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
            else
            {
                entity.setState(new Long(state));
                entity.setParentid(helper.unescape(parentid));
                T_cms_navlink parentity =_linkService.findLinkbyID(parentid);
                if(parentity!=null) {
                    entity.setLevelnum(parentity.getLevelnum() + 1);
                }
                else {
                    entity.setLevelnum(new Long(1));
                }
                entity.setSitecode(helper.unescape(sitecode));
                entity.setModelcode(helper.unescape(modelcode));
                entity.setTitle(helper.unescape(title));
                entity.setLinkurl(helper.unescape(linkurl));
                entity.setIconurl(helper.unescape(iconurl));
                entity.setDisplaystate(new Long(displaystate));
                entity.setDisplaytype(new Long(displaytype));
                entity.setOrdernum(new Long(ordernum));
                entity.setCss(helper.unescape(css));
                entity.setRemark(helper.unescape(remark));
                entity.setModifiedby(userid);
                entity.setSubtitle(helper.unescape(subtitle));
                entity.setLinktarget(helper.unescape(linktarget));
                entity.setHtml(helper.unescape(html));
                result=_linkService.update(entity)>0;

                T_cms_navlinkrole upentity=new T_cms_navlinkrole();
                upentity.setNavlinkid(entity.getId());
                upentity.setState(new Long(0));
                upentity.setModifiedby(userid);
                _linkRoleService.updateStateBySelective(upentity);
                if(roles!=null && !roles.equals(""))
                {
                    List<String> addresult = Arrays.asList(roles.split(","));
                    List<T_cms_navlinkrole> addlist=new ArrayList<T_cms_navlinkrole>();
                    for(String rc:addresult)
                    {
                        if(rc!=null && !rc.equals("")) {
                            T_cms_navlinkrole rcentity = new T_cms_navlinkrole();
                            rcentity.setId(java.util.UUID.randomUUID().toString());
                            rcentity.setRolecode(rc);
                            rcentity.setNavlinkid(entity.getId());
                            rcentity.setState(new Long(1));
                            rcentity.setCreateby(userid);
                            rcentity.setModifiedby(userid);
                            addlist.add(rcentity);
                        }
                    }
                    if(addlist.size()>0) {
                        int size=100;
                        if(addlist.size()<=size) {
                            result &= _linkRoleService.insertByBatch(addlist) > 0;
                        }
                        else
                        {
                            int page=addlist.size()%size==0?addlist.size()/size:(addlist.size()/size)+1;
                            int begin=0;
                            int end=size;
                            for(int i=0;i<page;i++)
                            {
                                result &= _linkRoleService.insertByBatch(addlist.subList(begin,(end>addlist.size()?addlist.size():end))) > 0;
                                begin += size;
                                end = begin + size;
                            }
                        }
                    }
                }
                if(result) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存模板异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }



    @RequestMapping("/link/getrolelist")
    @ResponseBody
    public List<T_cms_role> getrolelist(String sitecode,String modelcode)
    {
        List<T_cms_role> list = new ArrayList<T_cms_role>();
        try {
            T_cms_role selective = new T_cms_role();
            selective.setState(new Long(1));
            selective.setSitecode(helper.unescape(sitecode));
            selective.setModelcode(helper.unescape(modelcode));
            selective.setRoletype(new Long(0));
            list = _roleService.findBySelective(selective);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/link/getlinkrolelist")
    @ResponseBody
    public List<T_cms_navlinkrole> getlinkrolelist(String id)
    {
        List<T_cms_navlinkrole> list = new ArrayList<T_cms_navlinkrole>();
        try {
            T_cms_navlinkrole selective = new T_cms_navlinkrole();
            selective.setNavlinkid(helper.unescape(id));
            list = _linkRoleService.findBySelective(selective);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }



}
