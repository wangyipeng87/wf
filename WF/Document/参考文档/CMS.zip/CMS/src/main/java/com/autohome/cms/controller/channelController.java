package com.autohome.cms.controller;

import com.autohome.cms.Entity.*;
import com.autohome.cms.service.ChannelService;
import com.autohome.cms.service.RoleService;
import com.autohome.cms.service.RoleUserService;
import com.autohome.common.LoggerHelper;
import com.autohome.common.Result;
import com.autohome.common.TimestampTypeAdapter;
import com.autohome.common.helper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Administrator on 2017/5/23.
 */
@Controller
public class channelController extends baseController {

    @Resource
    ChannelService _channelService;
    @Resource
    RoleService _roleService;
    @Resource
    RoleUserService _roleUserService;
    @RequestMapping("/channel/channelList")
    public ModelAndView showHomePage() {

        //   Model model=new Model() ;
        ModelAndView mod = new ModelAndView("jsps/CMS/ChannelManage/channelList");
        return mod;
    }

    @RequestMapping("/channel/GetList")
    @ResponseBody
    public Result GetList( String parentcode,String name, String createuser, int state, String channeltype, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        name = helper.unescape(name);
        createuser = helper.unescape(createuser);
        channeltype = helper.unescape(channeltype);
        ArrayList<channel> list = new ArrayList<channel>();
        try {
            list = _channelService.findchannel(parentcode,name, createuser, state, channeltype, getCurrentUser().getUsercode(), "", orderdata, orderdir, begin, end);
            int tot = _channelService.findchannelCount(parentcode,name, createuser, state, channeltype, getCurrentUser().getUsercode(), "");
            if (list == null && list.size() == 0) {
                list = new ArrayList<channel>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/channel/updatestate")
    @ResponseBody
    public int updatestate(String id, int state) {
        try {
            _channelService.UpdateState(id, state);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }
    @RequestMapping("/channel/hasRoleCode")
    @ResponseBody
    public int hasRoleCode(String rolecode,String id) {
        try {
            return  _roleService.hasRoleCode(rolecode, "",id);
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }
    @RequestMapping("/channel/isorder")
    @ResponseBody
    public int isorder(String id, int order) {
        int i = 1;
        try {
            return   _channelService.isorder(id, order);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/channel/updateorder")
    @ResponseBody
    public int updateorder(String id, int order) {
        int i = 1;
        try {
            channel entity=_channelService.findbyID(id);
            _channelService.updateorder(id,order,  (int)entity.getorderid());
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/channel/add")
    public ModelAndView add() {
        String fromname="编辑";
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
            fromname="新增";
        }
        T_employee emp = getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/ChannelManage/channelAdd");
        mod.addObject("id", id);
        mod.addObject("fromname", fromname);
        return mod;
    }

    @RequestMapping("/channel/getbyid")
    @ResponseBody
    public channel getbyid(@RequestParam(value = "id") String id) {
        channel entity = _channelService.findbyID(id);
        if (entity == null) {
            entity = new channel();
            entity.setid(java.util.UUID.randomUUID().toString());
            entity.setstate(1);
            entity.setorderid(_channelService.getmaxorder()+1);
        }
        return entity;
    }

    @RequestMapping("/channel/save")
    @ResponseBody
    public int save(String id, String name,String style, String description, String channeltype, String parentcode, int ischild, int orderid, int state) {
        try {
            channel entity = new channel();
            entity = _channelService.findbyID(id);
            if (entity == null) {
                entity = new channel();
                entity.setid(java.util.UUID.randomUUID().toString());
                entity.setcreateuserid(getCurrentUser().getUserid());
            }
            entity.setname(helper.unescape(name));
            entity.setstyle(helper.unescape(style));
            entity.setdescription(helper.unescape(description));
            entity.setparentcode(helper.unescape(parentcode));
            entity.setischild(ischild);
            entity.setorderid(orderid);
            entity.setstate(state);
            entity.setsitecode(helper.unescape(""));
            entity.setupdateuserid(getCurrentUser().getUserid());
            entity.setchanneltype(helper.unescape(channeltype));
            _channelService.save(entity);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/channel/GetListForSelect")
    @ResponseBody
    public ArrayList<channel> GetListForSelect(@RequestParam(value = "ischild") int ischild, @RequestParam(value = "channeltype") String channeltype) {
        //String sitecode,
        channeltype = helper.unescape(channeltype);
        ArrayList<channel> list = new ArrayList<channel>();
        try {
            list = _channelService.findchannelforselect(getCurrentUser().getUsercode(), "", channeltype, ischild);

        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/channel/GetListForRoleSelect")
    @ResponseBody
    public ArrayList<channel> GetListForRoleSelect(@RequestParam(value = "ischild") int ischild, @RequestParam(value = "channeltype") String channeltype) {
        //String sitecode,
        channeltype = helper.unescape(channeltype);
        ArrayList<channel> list = new ArrayList<channel>();
        try {
            list = _channelService.findchannelforRoleselect(-1,"", channeltype, ischild);

        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/channel/GetListForAdd")
    @ResponseBody
    public List<channel> GetListForSelect(@RequestParam(value = "parentcode") String parentcode, @RequestParam(value = "ischild") int ischild, @RequestParam(value = "channeltype") String channeltype) {
        //String sitecode,
        channeltype = helper.unescape(channeltype);
        ArrayList<channel> list = new ArrayList<channel>();
        List<channel> rootlist = null;
        try {
            list = _channelService.findchannelforselect(getCurrentUser().getUsercode(), "", channeltype, ischild);
            if (list.stream().anyMatch(x -> x.getparentcode() == parentcode || (x.getparentcode() != null && x.getparentcode().equals(parentcode)))) {
                rootlist = list.stream().filter(x -> x.getparentcode() == parentcode || (x.getparentcode() != null && x.getparentcode().equals(parentcode))).sorted(menuComparator).collect(Collectors.toList());
            }
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        if (rootlist == null) {
            rootlist = new ArrayList<channel>();
        }
        return rootlist;
    }

    public Comparator<channel> menuComparator = new Comparator<channel>() {
        @Override
        public int compare(channel o1, channel o2) {
            if (o1.getorderid() > o2.getorderid()) return 1;
            if (o1.getorderid() < o2.getorderid()) return -1;
            return 0;
        }
    };

    //
    @RequestMapping("/channel/channelAuthority")
    @ResponseBody
    public ModelAndView channelAuthority() {
        ModelAndView mod = new ModelAndView("jsps/CMS/ChannelManage/channelAuthority");
        return mod;
    }

    @RequestMapping("/channel/GetRoleList")
    @ResponseBody
    public Result GetRoleList(int roletype, String keyword, int state, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        keyword = helper.unescape(keyword);
        ArrayList<T_role> list = new ArrayList<T_role>();
        try {
            list = _roleService.findroleForChannel(roletype, keyword, state, orderdata, orderdir, begin, end);
            int tot = _roleService.findroleForChannelcount(roletype, keyword, state, orderdata, orderdir);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_role>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/channel/GetUserByRole")
    @ResponseBody
    public Result GetUserByRole(String rolecode, int state, String keyword, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        keyword = helper.unescape(keyword);
        rolecode = helper.unescape(rolecode);
        ArrayList<roleuser> list = new ArrayList<roleuser>();
        try {
            list = _employeeService.findByrolecode(rolecode, state, keyword, orderdata, orderdir, begin, end);
            int tot = _employeeService.findcountByrolecode(rolecode, state, keyword, orderdata, orderdir);
            if (list == null && list.size() == 0) {
                list = new ArrayList<roleuser>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/channel/emplist")
    public ModelAndView emplist() {
        String id = helper.getParameter("rolecode");
        ModelAndView mod = new ModelAndView("jsps/CMS/ChannelManage/EmpList");
        mod.addObject("rolecode", id);
        return mod;
    }

    @RequestMapping("/channel/addrole")
    public ModelAndView addrole() {
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        ModelAndView mod = new ModelAndView("jsps/CMS/ChannelManage/AddRole");
        mod.addObject("id", id);
        return mod;
    }

    @RequestMapping("/channel/getrolebyid")
    @ResponseBody
    public T_role getrolebyid() {
        String id = helper.getParameter("id");
        T_role role = _roleService.findbyid(id);
        if (role == null) {
            role = new T_role();
            role.setid(id);
            role.setstate(1);
        }
        return role;
    }

    @RequestMapping("/channel/saverole")
    @ResponseBody
    public int saveemplist(String jsonstring) {
        int i = 1;
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            T_role entity = gson.fromJson(jsonstring, T_role.class);
            T_role form = _roleService.findbyid(entity.getid());
            if (form == null) {
                entity.setid(java.util.UUID.randomUUID().toString());
                entity.setcreateusercode(getCurrentUser().getUsercode());
                entity.setupdateusercode(getCurrentUser().getUsercode());
            } else {
                entity.setupdateusercode(getCurrentUser().getUsercode());
            }
            entity.setsitecode("");
            _roleService.save(entity);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/channel/saveroleuser")
    @ResponseBody
    public int saveroleuser(String jsonstring) {
        int i = 1;
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            T_cms_role_user entity = gson.fromJson(jsonstring, T_cms_role_user.class);
            entity.setid(java.util.UUID.randomUUID().toString());
            entity.setcreateusercode(getCurrentUser().getUsercode());
            entity.setupdateusercode(getCurrentUser().getUsercode());
            _roleUserService.add(entity);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/channel/updateroleuser")
    @ResponseBody
    public int updateroleuser(String id, int state) {
        int i = 1;
        try {
            _roleUserService.update(id, state);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/channel/updaterole")
    @ResponseBody
    public int updaterole(String id, int state) {
        int i = 1;
        try {
            _roleService.update(id, state);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/channel/getemplist")
    @ResponseBody
    public ArrayList<T_employee> getemplist(String keyword,String rolecode) {
        ArrayList<T_employee> list = new ArrayList<T_employee>();
        keyword = helper.unescape(keyword);
        try {
            list = _employeeService.findempforautocomplete(keyword,"",rolecode);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/channel/AddUser")
    public ModelAndView addRoleUser() {
        String rolecode = helper.getParameter("rolecode");
        ModelAndView mod = new ModelAndView("jsps/CMS/ChannelManage/AddUser");
        T_role role = _roleService.findbycode(rolecode);
        mod.addObject("rolecode", rolecode);
        mod.addObject("rolename", role.getrolename());
        return mod;
    }

    @RequestMapping("/channel/getChannelByParentCode")
    @ResponseBody
    public ArrayList<T_cms_channel> getChannelByParentCode() {
        String parentCode = helper.getParameter("ParentCode");
        ArrayList<T_cms_channel> list = new ArrayList<T_cms_channel>();
        try {
            list = _channelService.findChannelByParentCode(parentCode);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }
}
