package com.autohome.cms.controller;

import com.autohome.cms.Entity.*;
import com.autohome.cms.common.CmnFunction;
import com.autohome.cms.service.*;
import com.autohome.common.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/5/22.
 */
@Controller
public class contentController extends baseController {
    //    @Value("#{configProperties['ContentStaticUrl']}")
//    private String ContentStaticUrl;
//    @Value("#{configProperties['ArticleStaticPath']}")
//    private String ArticleStaticPath;
//    @Value("#{configProperties['ContentTemplate']}")
//    private String ContentTemplate;

    @Value("#{configProperties['ShareChannelID']}")
    private String ShareChannelID;

    @Value("#{configProperties['RuleChannelID']}")
    private String RuleChannelID;
    @Resource
    ContentService _contentService;
    @Resource
    FocusService _focusService;
    @Resource
    DeptinfoService _deptinfoService;
    @Resource
    ContentFileService _contentFileService;
    @Resource
    KnowledgeformService _knowledgeformService;
    @Resource
    KnowledgeFileService _knowledgeFileService;
    @Resource
    KnowledgedepartService _knowledgedepartService;
    @Resource
    EmployeeService _employeeService;
    @Resource
    KnowledgeuserService _knowledgeuserService;
    //焦点图
//    @Value("#{configProperties['FocusMap']}")
//    private String FocusMap;
    //通知公告
//    @Value("#{configProperties['Notices']}")
//    private String Notices;


    @RequestMapping("/content/contentList")
    public ModelAndView showHomePage() {

        //   Model model=new Model() ;
        ModelAndView mod = new ModelAndView("jsps/CMS/ContentManage/contentList");
        mod.addObject("name", "我测试的啊ModelAndView,站点");

        mod.addObject("ruleChannelID", this.RuleChannelID);
        mod.addObject("shareChannelID", this.ShareChannelID);
        return mod;
    }

    @RequestMapping("/content/GetList")
    @ResponseBody
    public Result GetList(int istop, String parentid, String catalogid, String title, int state, String createusername, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        catalogid = helper.unescape(catalogid);
        if (catalogid == null || catalogid.equals("")) {
            catalogid = "00000000-0000-0000-0000-000000000000";
        }
        title = helper.unescape(title);
        createusername = helper.unescape(createusername);
        ArrayList<content> list = new ArrayList<content>();
        ArrayList<String> exinclud=new ArrayList<String>();
        exinclud.add(this.RuleChannelID);
        exinclud.add(this.ShareChannelID);
        try {
            list = _contentService.findcontent(exinclud,istop, -1, "content", parentid, catalogid, title, state, createusername, getCurrentUser().getUsercode(), "", orderdata, orderdir, begin, end);
            int tot = _contentService.findcontentCount(exinclud,istop, -1, "content", parentid, catalogid, title, state, createusername, getCurrentUser().getUsercode(), "", orderdata, orderdir);
            if (list == null && list.size() == 0) {
                list = new ArrayList<content>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/content/focusList")
    public ModelAndView focusList() {
        ModelAndView mod = new ModelAndView("jsps/CMS/ContentManage/focusList");
        return mod;
    }

    @RequestMapping("/content/addfcous")
    @ResponseBody
    public int addfcous(String jsonstring) {
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            Type type = new TypeToken<ArrayList<String>>() {
            }.getType();
            ArrayList<String> codelist = gson.fromJson(jsonstring, type);
            _focusService.add(codelist, getCurrentUser().getUsercode());
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/content/delfcous")
    @ResponseBody
    public int delfcous(String jsonstring) {
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            Type type = new TypeToken<ArrayList<String>>() {
            }.getType();
            ArrayList<String> codelist = gson.fromJson(jsonstring, type);
            _focusService.del(codelist);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/content/releatefocus")
    public ModelAndView releatefocus() {

        //   Model model=new Model() ;
        ModelAndView mod = new ModelAndView("jsps/CMS/ContentManage/releatefocus");
        return mod;
    }

    @RequestMapping("/content/GetFocusList")
    @ResponseBody
    public Result GetFocusList(String title, int state, String createusername, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();

        String parentid = "00000000-0000-0000-0000-000000000000";
        String catalogid = "00000000-0000-0000-0000-000000000000";
        title = helper.unescape(title);
        createusername = helper.unescape(createusername);
        ArrayList<content> list = new ArrayList<content>();
        try {
            list = _contentService.findcontentFcous(-1, "content", parentid, catalogid, title, state, createusername, getCurrentUser().getUsercode(), "", orderdata, orderdir, begin, end);
            int tot = _contentService.findcontentFcousCount(-1, "content", parentid, catalogid, title, state, createusername, getCurrentUser().getUsercode(), "", orderdata, orderdir);
            if (list == null && list.size() == 0) {
                list = new ArrayList<content>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }


    @RequestMapping("/content/findforreleate")
    @ResponseBody
    public Result findforreleate(String parentid, String catalogid, String title, int draw, int start, int length) {
        //region 获取排序字段
//        String orderdata = GetOrderdata();
//        String orderdir = GetOrderdir();
        //endregion
        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();
        catalogid = helper.unescape(catalogid);
        if (catalogid == null || catalogid.equals("")) {
            catalogid = "00000000-0000-0000-0000-000000000000";
        }
        title = helper.unescape(title);

        ArrayList<T_cms_content> list = new ArrayList<T_cms_content>();
        try {
            list = _contentService.findforreleate(parentid, catalogid, title, begin, end);
            int tot = _contentService.findcountforreleate(parentid, catalogid, title);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_cms_content>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/content/updatestate")
    @ResponseBody
    public int updatestate(String id, int state) {
        try {
            _contentService.UpdateState(id, state);
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/content/updateorder")
    @ResponseBody
    public int updateorder(String id, int order) {
        try {
            T_cms_content entity = _contentService.findByID(id);
            _contentService.updateorder(id, order, entity.getorderid() == null ? 0 : entity.getorderid());
            return 1;
        } catch (Exception ex) {
            LoggerHelper.error("添加评论异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }

    @RequestMapping("/content/add")
    public ModelAndView add() {
        String fromname = "编辑";
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
            fromname = "发布";
        }
        String from = helper.getParameter("from");
        T_employee emp = getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/ContentManage/contentAdd");
        mod.addObject("id", id);
//        mod.addObject("FocusMap", this.FocusMap);
//        mod.addObject("Notices", this.Notices);
        mod.addObject("from", from);
        mod.addObject("fromname", fromname);
        mod.addObject("ruleChannelID", this.RuleChannelID);
        mod.addObject("shareChannelID", this.ShareChannelID);
        return mod;
    }

    @RequestMapping("/content/getbyid")
    @ResponseBody
    public T_cms_content getbyid(@RequestParam(value = "id") String id) {
        T_cms_content entity = _contentService.findByID(id);
        if (entity == null) {
            entity = new T_cms_content();
            entity.setid(java.util.UUID.randomUUID().toString());
            entity.setstate(1);
            entity.setisnew(1);
        } else {
            entity.setisnew(0);
        }
        entity.setformtype("content");
        return entity;
    }

    @RequestMapping("/content/checkenable")
    @ResponseBody
    public String checkenable(@RequestParam(value = "id") String id) {
        String mess = "";
        T_cms_content entity = _contentService.findByID(id);
        if (entity.getparentcode() == null || entity.getparentcode().equals("")) {
            mess = mess + "请选择一级栏目<br/>";
        }
        if (entity.getchannelcode() == null || entity.getchannelcode().equals("")) {
            mess = mess + "请选择二级栏目<br/>";
        }
        if (entity.getcontenttitle() == null || entity.getcontenttitle().equals("")) {
            mess = mess + "请填写标题<br/>";
        }
        if (entity.getsummary() == null || entity.getsummary().equals("")) {
            mess = mess + "请填写简介<br/>";
        }
        if (entity.getisfocus() == 1) {
            if (entity.getsimplepicurl() == null || entity.getsimplepicurl().equals("")) {
                mess = mess + "请上传焦点图";
            }
        }
        return helper.escape(mess);
    }

    @RequestMapping("/content/getreldep")
    @ResponseBody
    public List<T_deptinfo> getrelateddep() {
        List<T_deptinfo> list = _deptinfoService.getDeptByParent("00000001");
        return list;
    }

    @RequestMapping("/content/GetFileList")
    @ResponseBody
    public ArrayList<T_cms_contentfile> GetFileList(String code) {
        ArrayList<T_cms_contentfile> list = new ArrayList<T_cms_contentfile>();
        try {
            list = _contentFileService.findByContentCode(code);
            if (list == null || list.size() == 0) {
                list = new ArrayList<T_cms_contentfile>();
            }

        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/content/save")
    @ResponseBody
    public int SaveContent(String jsonString) {
        int i = 1;
        try {
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            T_cms_content entity = gson.fromJson(jsonString, T_cms_content.class);
            T_cms_content form = _contentService.findByID(entity.getid());
            if (form == null) {
                //  entity.setid(java.util.UUID.randomUUID().toString());
                entity.setcreatedby(getCurrentUser().getUserid());
                entity.setmodifiedby(getCurrentUser().getUserid());
            } else {
                entity.setmodifiedby(getCurrentUser().getUserid());
            }
            entity.setisstatic(0);
            // entity.setprocessstate("Draft");
////            Date currentTime = new Date();
//            SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//            SimpleDateFormat formatterfile = new SimpleDateFormat("yyyyMMddHHmmss");
////            String dateString = formatter.format(currentTime);
//            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
//            String str=ReadWriteFile.readTxtFile(request.getSession().getServletContext().getRealPath(this.ContentTemplate+(this.ContentTemplate.endsWith("/") ? "" : "/")));
//            str.replace("$biaoti$",entity.getcontenttitle());
//            //str.replace("$biaoti$",entity.getcontenttitle());
//            str.replace("$time$",formatter.format(entity.getmodifiedon()));
//            str.replace("$createName$",entity.getcreatedby());
//            String filename=formatterfile.format(new Date())+".html";
//            String path =this.ContentStaticUrl+filename;
//             path=request.getSession().getServletContext().getRealPath(path+(path.endsWith("/") ? "" : "/"));
//            entity.setstaticpathurl(this.ArticleStaticPath+filename);
//            ReadWriteFile.creatTxtFile(path);
//            ReadWriteFile.writeTxtFile(path,str);
            if (entity.getprocessstate() != null && entity.getprocessstate().equals("Release")) {
                if (entity.getpublishtime() == null) {
                    entity.setpublishtime(new Timestamp(System.currentTimeMillis()));
                }
            }
            entity.setisdelete(0);
            entity.setsitecode("");
            System.out.println("BreviaryPicUrl=========:"+entity.getBreviaryPicUrl());
            System.out.println("simplepicurl=========:"+entity.getsimplepicurl());
            _contentService.save(entity);
        } catch (Exception ex) {
            i = 0;
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return i;
    }

    @RequestMapping("/content/GetEmpList")
    @ResponseBody
    public Result GetEmpList(String ids, String keyword, int draw, int start, int length) {

        int begin = start == 0 ? start : start + 1;
        int end = start == 0 ? start + length : start + length;
        Result res = new Result();

        keyword = helper.unescape(keyword);
        ArrayList<T_employee> list = new ArrayList<T_employee>();
        ArrayList<String> idlist = new ArrayList<String>();
        if (ids != null && !ids.equals("")) {
            String[] idarray = ids.split(",");
            if (idarray != null && idarray.length > 0) {
                for (int i = 0; i < idarray.length; i++) {
                    idlist.add(idarray[i]);
                }
            }
        }
        try {
            list = _employeeService.findByknowledgeid(idlist, keyword, begin, end);
            int tot = _employeeService.findcountByknowledgeid(idlist, keyword);
            if (list == null && list.size() == 0) {
                list = new ArrayList<T_employee>();
            }
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }

    @RequestMapping("/content/ChooseEmp")
    public ModelAndView ChooseEmp() {
        String id = helper.getParameter("id");
        if (id == null || id.equals("")) {
            id = java.util.UUID.randomUUID().toString();
        }
        T_employee emp = getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/ContentManage/ChooseEmp");
        mod.addObject("id", id);
        return mod;
    }

    @RequestMapping("/content/del")
    @ResponseBody
    public ResultMsg delbyid(@RequestParam(value = "id") String id) {
        ResultMsg ret = new ResultMsg();
        String userid = getCurrentUser().getUserid();
        Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
        try {
            if (id != null && !id.equals("")) {
                T_cms_content item = _contentService.findByID(id);
                String beforeContent = gson.toJson(item);
                item.setisdelete(1);//0未删除 1已删除
                boolean result = _contentService.deleteList(id, getCurrentUser());
                if (result) {
                    ret.setState(1);
                    ret.setMsg("删除成功");

                    //插入操作日志
                    CmnFunction.InsertOperationLog(item.getsitecode(), OperationType.Update, FormType.T_CMS_Content, item.getid(), beforeContent, gson.toJson(item));
                } else {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            } else {
                ret.setState(0);
                ret.setMsg("没有要删除的行");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/content/dellist")
    @ResponseBody
    public ResultMsg delListByIds(@RequestParam(value = "ids") String ids) {
        ResultMsg ret = new ResultMsg();
        T_employee user = getCurrentUser();
        try {
            if (ids != null && ids.length() > 0) {
                String sqlIds = String.format("'%s'", ids.replace(",", "','"));
                boolean result = _contentService.deleteList(ids, user);
                if (result) {
                    ret.setState(1);
                    ret.setMsg("删除成功");
                } else {
                    ret.setState(0);
                    ret.setMsg("删除失败");
                }
            } else {
                ret.setState(0);
                ret.setMsg("没有要删除的行");
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("删除失败");
            LoggerHelper.error("批量删除文章操作异常，操作人:" + user.getUsername() + "(" + user.getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    //更新焦点图有效日期
    @RequestMapping("/content/updatedate")
    @ResponseBody
    public int updatedate(String id, String start, String end) {
        try {
            T_cms_content entity = _contentService.findByID(id);
            Gson gson = new GsonBuilder().serializeNulls().registerTypeAdapter(Timestamp.class, new TimestampTypeAdapter()).setDateFormat("yyyy-MM-dd HH:mm:ss").create();
            String beforeContent = gson.toJson(entity);
            entity.setbegindate(Timestamp.valueOf(String.format("%s 00:00:00", start)));
            entity.setenddate(Timestamp.valueOf(String.format("%s 23:59:59", end)));

            if (_contentService.save(entity)) {
                CmnFunction.InsertOperationLog(entity.getsitecode(), OperationType.Update, FormType.T_CMS_Content, entity.getid(), beforeContent, gson.toJson(entity));
                return 1;
            } else {
                return 0;
            }
        } catch (Exception ex) {
            LoggerHelper.error("更新焦点图有效日期异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
            return 0;
        }
    }
}
