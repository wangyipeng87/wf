package com.autohome.cms.controller;

import com.autohome.common.HttpConnectUtil;
import com.autohome.common.PhotoResult;
import com.autohome.common.PropertyUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
public class homeController  extends baseController{

    @Value("#{configProperties['defaultHead']}")
    private String defaultHead;

    //
//    @Resource
//    SiteService _siteService;
//    @Resource
//    TmpService _tmpService;
//    @Value("#{configProperties['AccessTmpUrl']}")
//    private String AccessTmpUrl;
//
//    @RequestMapping("/{site}/page")
//    public ModelAndView showHomePage(@PathVariable String site){
//        T_cms_site entity=_siteService.findSitebyPrefix(site);
//        T_cms_tmp tmp= _tmpService.findTmpbycode(entity.getTmpCode());
//        ModelAndView mod = new ModelAndView("tmps/"+tmp.getFoldername()+"/index");
//        mod.addObject("name", "我测试的啊ModelAndView,站点"+site);
//        return mod;
//    }
//    @RequestMapping("/{site}")
//    public ModelAndView homepage(@PathVariable String site){
//        T_cms_site entity=_siteService.findSitebyPrefix(site);
//        T_cms_tmp tmp= _tmpService.findTmpbycode(entity.getTmpCode());
//        ModelAndView mod = new ModelAndView("tmps/"+tmp.getFoldername()+"/index");
//        mod.addObject("name", "我测试的啊ModelAndView,站点"+site);
//        return mod;
//    }
//    @RequestMapping("/{site}/jsp")
//    public ModelAndView jsp(@PathVariable String site){
//        ModelAndView mod = new ModelAndView("jsps/"+site+"/index2");
//        mod.addObject("name", "我测试的啊ModelAndView,站点"+site);
//        return mod;
//    }
//    @RequestMapping("/head")
//    public ModelAndView head(){
//        ModelAndView mod = new ModelAndView("jsps/CMS/head");
//        mod.addObject("name", Math.random());
//        return mod;
//    }
//
    @RequestMapping("/manage")
    public ModelAndView index() {
        ModelAndView mod = new ModelAndView("jsps/CMS/index");
        mod.addObject("emp", getCurrentUser());
        return mod;
    }

    @RequestMapping("/home/index")
    public ModelAndView homeindex() {
        ModelAndView mod = new ModelAndView("jsps/CMS/homeindex");
        return mod;
    }

    @RequestMapping("/home/GetConfig")
    @ResponseBody
    public String GetConfig(String key) {
        return PropertyUtil.getProperty(key, "");
    }

    @RequestMapping("/home/GetUserImg")
    @ResponseBody
    public String GetUserImg(String usercode, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
        String url = "";
        Map<String, String> msp = new HashMap<String, String>();
        String resjosn = HttpConnectUtil.sendPost(PropertyUtil.getProperty("imgurl") + "?usercode=" + usercode, msp);
        if (resjosn != null && !resjosn.equals("") && resjosn.length() > 0) {
            Gson gson = new GsonBuilder().serializeNulls().create();
            PhotoResult entity = gson.fromJson(resjosn, PhotoResult.class);
            if (entity != null && entity.getdata() != null && entity.getdata().getprofile() != null && !entity.getdata().getprofile().equals("")) {
                url = entity.getdata().getprofile();
            }
        } else {
            url =request.getContextPath()+ this.defaultHead;
        }
        return url;
    }

    @RequestMapping("/home/logout")
    public ModelAndView LogOut() throws IOException {
        //获取request对象并清空session
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        request.getSession().setAttribute("emp", null);
        request.getSession().invalidate();
        //获取web.xml中配置的登出信息并跳转
        ServletContext appliction = request.getServletContext();
        String redirectUrl = String.format("%s?service=%s",
                appliction.getFilterRegistration("casSingleSignOutFilter").getInitParameter("casServerLogoutUrl"),
                appliction.getFilterRegistration("casSingleSignOutFilter").getInitParameter("serverName"));
        //跳转
        HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getResponse();
        response.sendRedirect(redirectUrl);
        return null;
    }

//
//    //单页访问
//    @RequestMapping("/{site}/page/{pagename}")
//    public ModelAndView showStaticPage(@PathVariable String site, @PathVariable String pagename,  HttpServletRequest request, HttpServletResponse response, HttpSession session)
//    {
//        T_cms_site entity=_siteService.findSitebyPrefix(site);
//        T_cms_tmp tmp= _tmpService.findTmpbycode(entity.getTmpCode());
//
//        //model.addAttribute("tmppath",session.getServletContext().getContextPath()+AccessTmpUrl+tmp.getFoldername()+"/");
//
//        ModelAndView mod = new ModelAndView("tmps/"+tmp.getFoldername()+"/page/"+pagename);
//        mod.addObject("tmppath",session.getServletContext().getContextPath()+AccessTmpUrl+tmp.getFoldername()+"/");
//        return mod;
//    }
//
//
//
//    @RequestMapping(value = "/controller")
//    public String controller() {
//        return "jsps/CMS/controller";
//    }

}