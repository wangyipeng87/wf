package com.autohome.cms.controller;

import com.autohome.cms.Entity.T_cms_model;
import com.autohome.cms.Entity.T_cms_site;
import com.autohome.cms.Entity.T_employee;
import com.autohome.cms.service.ModelService;
import com.autohome.cms.service.SiteService;
import com.autohome.common.LoggerHelper;
import com.autohome.common.Result;
import com.autohome.common.ResultMsg;
import com.autohome.common.helper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/6/3.
 */

@Controller
public class modelController extends baseController {

    @Resource
    SiteService _siteService;
    @Resource
    ModelService _modelService;

    @RequestMapping("/model/list")
    public ModelAndView listPage(){
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/ModelManage/ModelList");
        mod.addObject("username",emp.getUsername());
        return mod;
    }

    @RequestMapping("/model/add")
    public ModelAndView add(){
        String fromname="编辑";
        String id= helper.getParameter("id");
        if(id==null||id.equals(""))
        {
            id = java.util.UUID.randomUUID().toString();
            fromname="添加";
        }
        T_employee emp= getCurrentUser();
        ModelAndView mod = new ModelAndView("jsps/CMS/ModelManage/AddModel");
        mod.addObject("username",emp.getUsername());
        mod.addObject("id",id);
        mod.addObject("fromname", fromname);
        return mod;
    }


    @RequestMapping("/model/GetAllList")
    @ResponseBody
    public Result GetList(String name,String code,String sitecode, int draw, int start, int length) {
        //region 获取排序字段
        String orderdata = GetOrderdata();
        String orderdir = GetOrderdir();
        //endregion
        int begin=start==0?start:start+1;
        int end=start==0?start+length:start+length;
        Result res=new Result();
        name= helper.unescape(name);
        sitecode= helper.unescape(sitecode);
        code= helper.unescape(code);
        ArrayList<T_cms_model> list = new ArrayList<T_cms_model>();
        try {
            list=_modelService.findAllPager(name,code,sitecode,orderdata,orderdir,begin,end);
            if(list==null)
            {
                list = new ArrayList<T_cms_model>();
            }
            int tot=_modelService.findAllCount(name,code,sitecode);
            res.setdata(list);
            res.setdraw(draw);
            res.setrecordsFiltered(tot);
            res.setrecordsTotal(tot);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return res;
    }


    @RequestMapping("/model/updatestate")
    @ResponseBody
    public ResultMsg updatestate(String id, int state) {
        ResultMsg ret=new ResultMsg();
        try {
            T_cms_model entity =new T_cms_model();
            entity.setId(id);
            entity.setState(new Long(state));
            entity.setModifiedby(getCurrentUser().getUserid());
            int result=_modelService.updateState(entity);
            if(result>0) {
                ret.setState(1);
                ret.setMsg("保存成功");
            }
            else
            {
                ret.setState(0);
                ret.setMsg("保存失败");
            }
        }
        catch (Exception ex)
        {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("变更状态异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }

    @RequestMapping("/model/getbyid")
    @ResponseBody
    public T_cms_model getbyid(@RequestParam(value = "id") String id){
        T_cms_model entity= _modelService.findbyID(id);
        if(entity==null) {
            entity=new T_cms_model();
            entity.setId(java.util.UUID.randomUUID().toString());
            entity.setState(new Long(1));
            entity.setModeltype(new Long(0));
        }
        return entity;
    }

    @RequestMapping("/model/GetSiteOptions")
    @ResponseBody
    public ArrayList<T_cms_site> GetSiteOptions() {
        ArrayList<T_cms_site> list = new ArrayList<T_cms_site>();
        try {
            list=_siteService.findAllSite("","","","",0,Integer.MAX_VALUE);
        } catch (Exception ex) {
            LoggerHelper.error("查询列表获取数据异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return list;
    }

    @RequestMapping("/model/save")
    @ResponseBody
    public ResultMsg save(String id, String modelcode, String sitecode, String modelname, int state, int modeltype, String remark) {
        ResultMsg ret=new ResultMsg();
        try {
            String userid=getCurrentUser().getUserid();
            T_cms_model entity =_modelService.findbyID(id);
            if(entity==null)
            {
                T_cms_model selective=new T_cms_model();
                selective.setModelcode(helper.unescape(modelcode));
                ArrayList<T_cms_model> chklist=_modelService.findBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    ret.setState(0);
                    ret.setMsg("模块编号已存在");
                    return ret;
                }
                entity=new T_cms_model();
                entity.setId(java.util.UUID.randomUUID().toString());
                entity.setState(new Long(state));
                entity.setCreateby(userid);
                entity.setSitecode(helper.unescape(sitecode));
                entity.setModelcode(helper.unescape(modelcode));
                entity.setModelname(helper.unescape(modelname));
                entity.setModeltype(new Long(modeltype));
                entity.setRemark(helper.unescape(remark));
                entity.setModifiedby(userid);
                int result=_modelService.insert(entity);
                if(result>0) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
            else
            {
                T_cms_model selective=new T_cms_model();
                selective.setModelcode(helper.unescape(modelcode));
                List<T_cms_model> chklist=_modelService.findBySelective(selective);
                if(chklist!=null && chklist.size()>0)
                {
                    long chkcount=chklist.stream().filter(chk -> !chk.getId().equals(id)).count();
                    if(chkcount>0) {
                        ret.setState(0);
                        ret.setMsg("模块编号已存在");
                        return ret;
                    }
                }
                entity.setState(new Long(state));
                entity.setSitecode(helper.unescape(sitecode));
                entity.setModelcode(helper.unescape(modelcode));
                entity.setModelname(helper.unescape(modelname));
                entity.setModeltype(new Long(modeltype));
                entity.setRemark(helper.unescape(remark));
                entity.setModifiedby(userid);
                int result=_modelService.update(entity);
                if(result>0) {
                    ret.setState(1);
                    ret.setMsg("保存成功");
                }
                else
                {
                    ret.setState(0);
                    ret.setMsg("保存失败");
                }
            }
        } catch (Exception ex) {
            ret.setState(0);
            ret.setMsg("保存失败");
            LoggerHelper.error("保存模板异常，操作人:" + this.getCurrentUser().getUsername() + "(" + this.getCurrentUser().getUsercode() + ")，异常信息：" + ex.toString());
        }
        return ret;
    }


}
